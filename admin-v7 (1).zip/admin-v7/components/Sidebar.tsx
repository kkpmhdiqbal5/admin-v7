'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

type Item = { href: string; icon: string; label: string; izin?: string | null };

const MENU: Item[] = [
  { href: '/dashboard', icon: 'fa-gauge', label: 'Dashboard', izin: null },
  { href: '/produk', icon: 'fa-boxes-stacked', label: 'Kelola Produk', izin: 'produk' },
  { href: '/produk-buat', icon: 'fa-square-plus', label: 'Buat Produk', izin: 'produk' },
  { href: '/akun', icon: 'fa-users', label: 'Kelola Akun', izin: 'akun' },
  { href: '/chat', icon: 'fa-headset', label: 'Live Chat', izin: 'chat' },
  { href: '/redeem', icon: 'fa-gift', label: 'Kode Redeem', izin: 'redeem' },
  { href: '/referral', icon: 'fa-share-nodes', label: 'Referral', izin: 'referral' },
  { href: '/vip', icon: 'fa-crown', label: 'Tingkat VIP', izin: 'vip' },
  { href: '/komunitas', icon: 'fa-users-rectangle', label: 'Komunitas', izin: 'komunitas' },
  { href: '/rekening', icon: 'fa-building-columns', label: 'Rekening & QRIS', izin: 'topup' },
  { href: '/topup', icon: 'fa-money-bill-transfer', label: 'Top Up Saldo', izin: 'topup' },
  { href: '/penarikan', icon: 'fa-hand-holding-dollar', label: 'Penarikan', izin: 'topup' },
  { href: '/tampilan', icon: 'fa-palette', label: 'Tampilan Client', izin: 'tampilan' },
  { href: '/checkin', icon: 'fa-calendar-check', label: 'Check-in Harian', izin: 'checkin' },
  { href: '/fonnte', icon: 'fa-brands fa-whatsapp', label: 'API OTP Fonnte', izin: 'fonnte' },
  { href: '/subadmin', icon: 'fa-user-shield', label: 'Sub-Admin', izin: 'admin_only' },
];

export default function Sidebar({
  username,
  role,
  izin,
}: {
  username: string;
  role: string;
  izin: string[];
}) {
  const path = usePathname();
  const router = useRouter();
  const isSuper = role === 'admin' || role === 'super_admin';
  const [chatClients, setChatClients] = useState(0);
  const [chatPesan, setChatPesan] = useState(0);

  useEffect(() => {
    let stop = false;
    async function tick() {
      try {
        const d = await (await fetch('/api/modules?mod=chat_unread')).json();
        if (!stop && d.status === 'sukses') {
          setChatClients(Number(d.clients || 0));
          setChatPesan(Number(d.pesan || 0));
        }
      } catch {
        /* ignore */
      }
    }
    tick();
    const t = setInterval(tick, 5000);
    return () => {
      stop = true;
      clearInterval(t);
    };
  }, [path]);

  function visible(item: Item) {
    if (item.izin === null) return true;
    if (item.izin === 'admin_only') return isSuper;
    if (isSuper) return true;
    return !!item.izin && izin.includes(item.izin);
  }

  async function logout() {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {
      /* ignore */
    }
    router.push('/login');
    router.refresh();
  }

  return (
    <nav className="sidebar">
      <div className="logo">
        V7 <span style={{ color: '#fff' }}>Admin</span>
        <small>
          {username} · {role}
        </small>
      </div>
      <ul className="nav-links">
        {MENU.filter(visible).map((item) => {
          const active = path === item.href || path.startsWith(item.href + '/');
          const isChat = item.href === '/chat';
          const badge = isChat ? chatClients || chatPesan : 0;
          return (
            <li key={item.href} className={active ? 'active' : ''}>
              <Link href={item.href} style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%' }}>
                <i className={`fa-solid ${item.icon}`} />
                <span style={{ flex: 1 }}>{item.label}</span>
                {isChat && badge > 0 && (
                  <span
                    title={`${chatClients} client · ${chatPesan} pesan belum dibaca`}
                    style={{
                      background: '#ef4444',
                      color: '#fff',
                      fontSize: 10,
                      fontWeight: 800,
                      minWidth: 18,
                      height: 18,
                      borderRadius: 9,
                      display: 'inline-flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: '0 5px',
                    }}
                  >
                    {chatClients > 0 ? chatClients : chatPesan > 9 ? '9+' : chatPesan}
                  </span>
                )}
              </Link>
            </li>
          );
        })}
      </ul>
      <button className="btn btn-ghost" style={{ width: '100%', marginTop: 12 }} onClick={logout}>
        <i className="fa-solid fa-right-from-bracket" /> Keluar
      </button>
    </nav>
  );
}
