const SUPABASE_URL = (process.env.SUPABASE_URL || 'https://jhlvmkeggmiwdamncxd.supabase.co').replace(/\/$/, '');
const SUPABASE_SECRET = (process.env.SUPABASE_SECRET || process.env.SUPABASE_SERVICE_ROLE_KEY || '').trim();
const SUPABASE_BUCKET = (process.env.SUPABASE_BUCKET || 'produk').trim();

function toBuffer(data: Buffer | Uint8Array | ArrayBuffer): Buffer {
  if (Buffer.isBuffer(data)) return data;
  if (data instanceof ArrayBuffer) return Buffer.from(data);
  return Buffer.from(data.buffer, data.byteOffset, data.byteLength);
}

async function tryFetch(
  url: string,
  init: RequestInit,
  retries = 2
): Promise<Response> {
  let lastErr: unknown;
  for (let i = 0; i <= retries; i++) {
    try {
      return await fetch(url, init);
    } catch (e) {
      lastErr = e;
      if (i < retries) await new Promise((r) => setTimeout(r, 400 * (i + 1)));
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error('fetch failed');
}

export async function supabaseUpload(
  data: Buffer | Uint8Array | ArrayBuffer,
  remotePath: string,
  mime: string
): Promise<{ ok: true; path: string; url: string } | { ok: false; error: string }> {
  if (!SUPABASE_SECRET) {
    return {
      ok: false,
      error:
        'SUPABASE_SECRET kosong di Vercel. Isi service_role (eyJ...) dari Supabase → API Keys → Legacy, lalu Redeploy.',
    };
  }

  const path = remotePath.replace(/^\//, '');
  const body = toBuffer(data);
  const contentType = mime || 'image/jpeg';
  const endpoint = `${SUPABASE_URL}/storage/v1/object/${SUPABASE_BUCKET}/${path}`;
  const auth = {
    Authorization: `Bearer ${SUPABASE_SECRET}`,
    apikey: SUPABASE_SECRET,
    'x-upsert': 'true',
  };

  let lastError = '';

  // 1) PUT binary
  try {
    const res = await tryFetch(endpoint, {
      method: 'PUT',
      headers: { ...auth, 'Content-Type': contentType },
      body,
    });
    if (res.ok) {
      return {
        ok: true,
        path,
        url: `${SUPABASE_URL}/storage/v1/object/public/${SUPABASE_BUCKET}/${path}`,
      };
    }
    const text = await res.text().catch(() => '');
    lastError = `PUT ${res.status}: ${text.slice(0, 200)}`;
    if (res.status === 401 || res.status === 403) {
      return {
        ok: false,
        error:
          lastError +
          ' | Key ditolak. Ganti SUPABASE_SECRET = service_role Legacy (eyJ...) di Vercel admin, Redeploy.',
      };
    }
  } catch (e) {
    lastError = `PUT network: ${e instanceof Error ? e.message : 'fetch failed'}`;
  }

  // 2) POST binary
  try {
    const res = await tryFetch(endpoint, {
      method: 'POST',
      headers: { ...auth, 'Content-Type': contentType },
      body,
    });
    if (res.ok) {
      return {
        ok: true,
        path,
        url: `${SUPABASE_URL}/storage/v1/object/public/${SUPABASE_BUCKET}/${path}`,
      };
    }
    const text = await res.text().catch(() => '');
    lastError = `POST ${res.status}: ${text.slice(0, 200)}`;
  } catch (e) {
    lastError = `POST network: ${e instanceof Error ? e.message : 'fetch failed'}`;
  }

  let hint = '';
  if (/fetch failed|network|ECONN|ETIMEDOUT/i.test(lastError)) {
    hint =
      ' | Cek SUPABASE_URL, bucket "produk" Public, dan SUPABASE_SECRET = eyJ service_role (bukan sb_secret jika masih gagal).';
  }
  if (/bucket|not found/i.test(lastError)) {
    hint = ` | Buat bucket "${SUPABASE_BUCKET}" di Supabase Storage → Public.`;
  }

  return { ok: false, error: (lastError + hint).slice(0, 700) };
}

export async function supabasePing(): Promise<{
  ok: boolean;
  url: string;
  keyType: string;
  keyPrefix: string;
  bucket: string;
  listStatus?: number;
  listBody?: string;
  error?: string;
}> {
  const keyType = SUPABASE_SECRET.startsWith('eyJ')
    ? 'legacy_jwt_service_role'
    : SUPABASE_SECRET.startsWith('sb_secret_')
      ? 'sb_secret'
      : SUPABASE_SECRET
        ? 'unknown'
        : 'empty';
  const keyPrefix = SUPABASE_SECRET ? SUPABASE_SECRET.slice(0, 20) + '…' : '(kosong)';

  if (!SUPABASE_SECRET) {
    return {
      ok: false,
      url: SUPABASE_URL,
      keyType,
      keyPrefix,
      bucket: SUPABASE_BUCKET,
      error: 'SUPABASE_SECRET kosong',
    };
  }

  try {
    const res = await tryFetch(`${SUPABASE_URL}/storage/v1/bucket/${SUPABASE_BUCKET}`, {
      headers: {
        Authorization: `Bearer ${SUPABASE_SECRET}`,
        apikey: SUPABASE_SECRET,
      },
    });
    const text = await res.text().catch(() => '');
    return {
      ok: res.ok,
      url: SUPABASE_URL,
      keyType,
      keyPrefix,
      bucket: SUPABASE_BUCKET,
      listStatus: res.status,
      listBody: text.slice(0, 300),
      error: res.ok ? undefined : text.slice(0, 300),
    };
  } catch (e) {
    return {
      ok: false,
      url: SUPABASE_URL,
      keyType,
      keyPrefix,
      bucket: SUPABASE_BUCKET,
      error: e instanceof Error ? e.message : 'ping failed',
    };
  }
}

export async function supabaseDelete(remotePath: string): Promise<{ ok: boolean; error?: string }> {
  if (!SUPABASE_SECRET) return { ok: false, error: 'SUPABASE_SECRET belum di-set' };

  let path = remotePath.replace(/^\//, '');
  const pub = `/object/public/${SUPABASE_BUCKET}/`;
  if (path.includes(pub)) path = path.split(pub)[1];
  if (path.startsWith('http')) {
    try {
      const u = new URL(path);
      const i = u.pathname.indexOf(`/${SUPABASE_BUCKET}/`);
      if (i >= 0) path = u.pathname.slice(i + SUPABASE_BUCKET.length + 2);
    } catch {
      /* */
    }
  }
  if (path.startsWith('uploads/')) path = `produk/${path.split('/').pop()}`;
  if (!path.startsWith('produk/') && !path.startsWith('avatars/')) path = `produk/${path}`;

  try {
    const res = await tryFetch(`${SUPABASE_URL}/storage/v1/object/${SUPABASE_BUCKET}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${SUPABASE_SECRET}`,
        apikey: SUPABASE_SECRET,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ prefixes: [path] }),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      return { ok: false, error: text || `HTTP ${res.status}` };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : 'delete error' };
  }
}

export function supabasePublicUrl(path: string | null | undefined): string {
  if (!path) return '';
  const raw = String(path).trim();
  if (!raw || raw === 'null') return '';
  if (/^https?:\/\//i.test(raw)) return raw;
  if (raw.startsWith('//')) return 'https:' + raw;

  let clean = raw.replace(/^\//, '');
  if (clean.includes(`storage/v1/object/public/`)) {
    return `${SUPABASE_URL}/${clean.replace(/^\//, '')}`;
  }
  if (clean.startsWith(SUPABASE_BUCKET + '/')) clean = clean.slice(SUPABASE_BUCKET.length + 1);
  if (clean.startsWith('uploads/')) clean = `produk/${clean.split('/').pop()}`;
  if (!clean.startsWith('produk/') && !clean.startsWith('avatars/')) clean = `produk/${clean}`;
  return `${SUPABASE_URL}/storage/v1/object/public/${SUPABASE_BUCKET}/${clean}`;
}
