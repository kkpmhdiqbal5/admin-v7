import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';
import { query, RowDataPacket } from './db';
import bcrypt from 'bcryptjs';

const COOKIE_NAME = 'v7_admin_token';
const SEMUA_IZIN = ['produk', 'akun', 'redeem', 'referral', 'vip', 'komunitas', 'topup', 'chat'] as const;
export type IzinKey = (typeof SEMUA_IZIN)[number];

export interface AdminSession {
  id: number;
  username: string;
  role: string;
  izin: string[];
}

function getSecret() {
  const s = process.env.JWT_SECRET;
  if (!s) throw new Error('JWT_SECRET belum di-set');
  return new TextEncoder().encode(s);
}

export async function createToken(payload: AdminSession): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('12h')
    .sign(getSecret());
}

export async function verifyToken(token: string): Promise<AdminSession | null> {
  try {
    const { payload } = await jwtVerify(token, getSecret());
    return {
      id: Number(payload.id),
      username: String(payload.username),
      role: String(payload.role),
      izin: Array.isArray(payload.izin) ? (payload.izin as string[]) : [],
    };
  } catch {
    return null;
  }
}

export async function getSession(): Promise<AdminSession | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

export async function requireSession(): Promise<AdminSession> {
  const s = await getSession();
  if (!s) throw new AuthError('Sesi admin tidak ditemukan, silakan login ulang');
  // Re-check status di DB agar nonaktif langsung berlaku
  const rows = await query<RowDataPacket[]>(
    'SELECT role, izin, status FROM admins WHERE id = ? LIMIT 1',
    [s.id]
  );
  if (!rows[0] || rows[0].status !== 'aktif') {
    throw new AuthError('Akun admin tidak aktif');
  }
  const role = String(rows[0].role);
  const izin =
    role === 'admin' || role === 'super_admin'
      ? [...SEMUA_IZIN]
      : String(rows[0].izin || '')
          .split(',')
          .map((x) => x.trim())
          .filter(Boolean);
  return { id: s.id, username: s.username, role, izin };
}

export function hasIzin(session: AdminSession, key: IzinKey): boolean {
  if (session.role === 'admin' || session.role === 'super_admin') return true;
  return session.izin.includes(key);
}

export async function loginAdmin(
  username: string,
  password: string
): Promise<{ ok: true; session: AdminSession } | { ok: false; pesan: string }> {
  const rows = await query<RowDataPacket[]>(
    'SELECT id, username, password, role, izin, status FROM admins WHERE username = ? LIMIT 1',
    [username.trim()]
  );
  const admin = rows[0];
  if (!admin || !(await bcrypt.compare(password, String(admin.password)))) {
    return { ok: false, pesan: 'Username atau password admin salah!' };
  }
  if (admin.status !== 'aktif') {
    return { ok: false, pesan: 'Akun admin ini dinonaktifkan!' };
  }
  const role = String(admin.role);
  const izin =
    role === 'admin' || role === 'super_admin'
      ? [...SEMUA_IZIN]
      : String(admin.izin || '')
          .split(',')
          .map((x) => x.trim())
          .filter(Boolean);

  const session: AdminSession = {
    id: Number(admin.id),
    username: String(admin.username),
    role,
    izin,
  };
  return { ok: true, session };
}

export function setAuthCookie(res: NextResponse, token: string) {
  res.cookies.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 12,
  });
}

export function clearAuthCookie(res: NextResponse) {
  res.cookies.set(COOKIE_NAME, '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 0,
  });
}

export class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AuthError';
  }
}

export async function getSessionFromRequest(
  req: NextRequest
): Promise<AdminSession | null> {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

export { COOKIE_NAME, SEMUA_IZIN };
