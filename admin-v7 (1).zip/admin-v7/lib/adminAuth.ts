import { cookies } from 'next/headers';
import { jwtVerify } from 'jose';

export async function requireAdmin() {
  const jar = await cookies();
  const t = jar.get('v7_admin_token')?.value;
  if (!t || !process.env.JWT_SECRET) throw new Error('Unauthorized');
  const { payload } = await jwtVerify(t, new TextEncoder().encode(process.env.JWT_SECRET));
  return {
    id: Number(payload.id),
    username: String(payload.username || ''),
    role: String(payload.role || ''),
  };
}
