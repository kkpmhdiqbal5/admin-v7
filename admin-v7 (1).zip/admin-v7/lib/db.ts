import mysql, { Pool, PoolConnection, RowDataPacket, ResultSetHeader } from 'mysql2/promise';

type SqlParam = string | number | boolean | null | Date | Buffer;

declare global {
  // eslint-disable-next-line no-var
  var _v7Pool: Pool | undefined;
}

// Admin: max 2 koneksi (cukup untuk ~5 admin, hemat kuota Aiven)
const POOL_LIMIT = Number(process.env.DB_POOL_LIMIT || 5);

function createPool(): Pool {
  return mysql.createPool({
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT || 22955),
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME || 'defaultdb',
    waitForConnections: true,
    connectionLimit: POOL_LIMIT,
    queueLimit: 20,
    enableKeepAlive: true,
    keepAliveInitialDelay: 10000,
    ssl: { rejectUnauthorized: false },
    timezone: '+07:00',
    charset: 'utf8mb4',
    connectTimeout: 8000,
  });
}

export function getPool(): Pool {
  if (!global._v7Pool) global._v7Pool = createPool();
  return global._v7Pool;
}

export async function query<T extends RowDataPacket[] = RowDataPacket[]>(
  sql: string,
  params: SqlParam[] = []
): Promise<T> {
  const [rows] = await getPool().execute<T>(sql, params);
  return rows;
}

export async function execute(sql: string, params: SqlParam[] = []): Promise<ResultSetHeader> {
  const [result] = await getPool().execute<ResultSetHeader>(sql, params);
  return result;
}

export async function withConnection<T>(fn: (conn: PoolConnection) => Promise<T>): Promise<T> {
  const conn = await getPool().getConnection();
  try {
    return await fn(conn);
  } finally {
    conn.release();
  }
}

export async function withTransaction<T>(fn: (conn: PoolConnection) => Promise<T>): Promise<T> {
  const conn = await getPool().getConnection();
  try {
    await conn.beginTransaction();
    const out = await fn(conn);
    await conn.commit();
    return out;
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}

export type { RowDataPacket, ResultSetHeader, PoolConnection };
