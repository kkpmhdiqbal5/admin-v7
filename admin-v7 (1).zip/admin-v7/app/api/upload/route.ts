import { NextRequest, NextResponse } from 'next/server';
import { randomBytes } from 'crypto';
import { requireSession, AuthError } from '@/lib/auth';
import { supabaseUpload } from '@/lib/supabase';

export const runtime = 'nodejs';
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    await requireSession();

    let form: FormData;
    try {
      form = await req.formData();
    } catch (e) {
      return NextResponse.json({
        status: 'error',
        pesan: 'Gagal baca file: ' + (e instanceof Error ? e.message : 'formData error'),
      });
    }

    const file = form.get('file') || form.get('gambar');
    if (!(file instanceof File) || file.size <= 0) {
      return NextResponse.json({ status: 'error', pesan: 'File kosong' });
    }
    if (file.size > 5 * 1024 * 1024) {
      return NextResponse.json({ status: 'error', pesan: 'Maksimal 5 MB' });
    }
    const mime = file.type || 'image/jpeg';
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/jpg'];
    if (mime && !allowed.includes(mime) && !mime.startsWith('image/')) {
      return NextResponse.json({ status: 'error', pesan: `Format tidak didukung: ${mime}` });
    }

    const ext =
      mime.includes('png') ? 'png' : mime.includes('webp') ? 'webp' : mime.includes('gif') ? 'gif' : 'jpg';
    const path = `produk/produk_${Date.now()}_${randomBytes(4).toString('hex')}.${ext}`;
    const buf = Buffer.from(await file.arrayBuffer());
    const up = await supabaseUpload(buf, path, mime || 'image/jpeg');
    if (!up.ok) {
      return NextResponse.json({ status: 'error', pesan: 'Upload gagal: ' + up.error });
    }
    return NextResponse.json({
      status: 'sukses',
      path: up.path,
      url: up.url,
      pesan: 'Upload berhasil',
    });
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ status: 'error', pesan: e.message }, { status: 401 });
    }
    return NextResponse.json({
      status: 'error',
      pesan: e instanceof Error ? e.message : 'Upload error',
    });
  }
}
