import { NextRequest, NextResponse } from 'next/server';
import { requireSession, hasIzin, AuthError } from '@/lib/auth';
import { query, execute, RowDataPacket } from '@/lib/db';
import { supabaseUpload, supabaseDelete, supabasePublicUrl } from '@/lib/supabase';
import { randomBytes } from 'crypto';

export const runtime = 'nodejs';
export const maxDuration = 60;


export async function GET(req: NextRequest) {
  try {
    await requireSession();
    const id = Number(req.nextUrl.searchParams.get('id') || 0);
    if (id > 0) {
      const rows = await query<RowDataPacket[]>(`SELECT * FROM produk WHERE id = ? LIMIT 1`, [id]);
      if (!rows[0]) return NextResponse.json({ status: 'error', pesan: 'Produk tidak ditemukan' });
      const row = rows[0];
      return NextResponse.json({
        status: 'sukses',
        data: { ...row, gambar_url: supabasePublicUrl(row.gambar as string) || row.gambar },
        produk: row,
      });
    }
    const rows = await query<RowDataPacket[]>(
      `SELECT id, nama_produk, jenis_produk, harga, stok, status, gambar FROM produk ORDER BY id DESC LIMIT 200`
    );
    return NextResponse.json({ status: 'sukses', data: rows });
  } catch (e) {
    return NextResponse.json({ status: 'error', pesan: e instanceof Error ? e.message : 'Error' }, { status: 401 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await requireSession();
    if (!hasIzin(session, 'produk')) {
      return NextResponse.json(
        { status: 'error', pesan: 'Anda tidak punya otoritas untuk aksi ini!' },
        { status: 403 }
      );
    }

    const contentType = req.headers.get('content-type') || '';
    let action = '';
    let data: Record<string, unknown> = {};
    let fileBuffer: Buffer | null = null;
    let fileMime = '';

    if (contentType.includes('multipart/form-data')) {
      const form = await req.formData();
      action = String(form.get('action') || '');
      form.forEach((v, k) => {
        if (k === 'gambar' && v instanceof File) {
          /* handled below */
        } else if (k !== 'action') {
          data[k] = typeof v === 'string' ? v : String(v);
        }
      });
      const gambar = form.get('gambar');
      if (gambar instanceof File && gambar.size > 0) {
        if (gambar.size > 3 * 1024 * 1024) {
          return NextResponse.json({ status: 'error', pesan: 'Ukuran gambar maksimal 3 MB!' });
        }
        const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        if (!allowed.includes(gambar.type)) {
          return NextResponse.json({
            status: 'error',
            pesan: 'Format gambar harus JPG, PNG, WEBP, atau GIF!',
          });
        }
        fileBuffer = Buffer.from(await gambar.arrayBuffer());
        fileMime = gambar.type;
      }
    } else {
      data = await req.json();
      action = String(data.action || '');
    }

    if (action === 'produk_status') {
      const id = Number(data.id || 0);
      const status = data.status === 'aktif' ? 'aktif' : 'nonaktif';
      if (id <= 0) {
        return NextResponse.json({ status: 'error', pesan: 'ID produk tidak valid' });
      }
      await execute('UPDATE produk SET status = ? WHERE id = ?', [status, id]);
      return NextResponse.json({ status: 'sukses', pesan: `Produk di${status === 'aktif' ? 'aktifkan' : 'nonaktifkan'}` });
    }

    if (action === 'produk_hapus') {
      const id = Number(data.id || 0);
      const rows = await query<RowDataPacket[]>('SELECT gambar FROM produk WHERE id = ? LIMIT 1', [id]);
      await execute('DELETE FROM produk WHERE id = ?', [id]);
      // cascade related if FK not set
      try {
        await execute('DELETE FROM transaksi_produk WHERE produk_id = ?', [id]);
      } catch { /* ignore */ }
      try {
        await execute('DELETE FROM riwayat_klaim_produk WHERE produk_id = ?', [id]);
      } catch { /* ignore */ }
      if (rows[0]?.gambar) {
        await supabaseDelete(String(rows[0].gambar));
      }
      return NextResponse.json({ status: 'sukses', pesan: 'Produk dihapus.' });
    }

    if (action === 'produk_buat_simpan' || action === 'produk_simpan') {
      const nama = String(data.nama_produk || '').trim();
      const jenis = String(data.jenis_produk || 'Umum').trim().slice(0, 50) || 'Umum';
      const deskripsi = String(data.deskripsi || '').trim();
      const harga = Number(data.harga || 0);
      const stok = Number(data.stok || 0);
      const durasi = Number(data.durasi_aktif_menit ?? data.durasi_menit ?? 0);
      const interval = Number(data.interval_aktif_menit ?? data.interval_menit ?? 0);
      const saldoKlaim = Number(data.saldo_per_klaim || 0);
      const maxKlaim = Number(data.max_klaim || 0);
      const levelProduk = Math.max(1, Number(data.level_produk || 1));
      const levelSyarat = data.level_syarat === 'aktif' ? 'aktif' : 'pernah';
      const maxBeliPerUser = Math.max(0, Number(data.max_beli_per_user || 0));
      const statusProduk = data.status === 'aktif' ? 'aktif' : 'nonaktif';
      const id = Number(data.id || 0);

      if (!nama || harga <= 0 || stok < 0) {
        return NextResponse.json({
          status: 'error',
          pesan: 'Nama, harga, dan stok wajib diisi dengan benar!',
        });
      }

      let gambarPath: string | null = data.gambar_path ? String(data.gambar_path) : null;
      if (fileBuffer) {
        const ext =
          fileMime === 'image/png'
            ? 'png'
            : fileMime === 'image/webp'
              ? 'webp'
              : fileMime === 'image/gif'
                ? 'gif'
                : 'jpg';
        const remote = `produk/produk_${randomBytes(8).toString('hex')}.${ext}`;
        const up = await supabaseUpload(fileBuffer, remote, fileMime);
        if (!up.ok) {
          return NextResponse.json({ status: 'error', pesan: 'Gagal upload gambar: ' + up.error });
        }
        gambarPath = up.path;
      }

      try { await execute(`ALTER TABLE produk ADD COLUMN level_produk INT NOT NULL DEFAULT 1`); } catch { /* */ }
      try { await execute(`ALTER TABLE produk ADD COLUMN level_syarat VARCHAR(16) NOT NULL DEFAULT 'pernah'`); } catch { /* */ }
      try { await execute(`ALTER TABLE produk ADD COLUMN max_beli_per_user INT NOT NULL DEFAULT 0`); } catch { /* */ }

      if (id > 0) {
        if (gambarPath) {
          const old = await query<RowDataPacket[]>('SELECT gambar FROM produk WHERE id = ?', [id]);
          await execute(
            `UPDATE produk SET nama_produk=?, jenis_produk=?, deskripsi=?, gambar=?, harga=?, stok=?,
             durasi_aktif_menit=?, interval_aktif_menit=?, saldo_per_klaim=?, max_klaim=?, status=? WHERE id=?`,
            [nama, jenis, deskripsi, gambarPath, harga, stok, durasi, interval, saldoKlaim, maxKlaim, statusProduk, id]
          );
          if (old[0]?.gambar) await supabaseDelete(String(old[0].gambar));
        } else {
          await execute(
            `UPDATE produk SET nama_produk=?, jenis_produk=?, deskripsi=?, harga=?, stok=?,
             durasi_aktif_menit=?, interval_aktif_menit=?, saldo_per_klaim=?, max_klaim=?, status=? WHERE id=?`,
            [nama, jenis, deskripsi, harga, stok, durasi, interval, saldoKlaim, maxKlaim, statusProduk, id]
          );
        }
        try {
          await execute(`UPDATE produk SET level_produk = ?, level_syarat = ?, max_beli_per_user = ? WHERE id = ?`, [levelProduk, levelSyarat, maxBeliPerUser, id]);
        } catch { /* */ }
        return NextResponse.json({ status: 'sukses', pesan: 'Produk berhasil diperbarui!' });
      }

      let insertId = 0;
      try {
        const result = await execute(
          `INSERT INTO produk
           (nama_produk, jenis_produk, deskripsi, gambar, harga, stok, durasi_aktif_menit, interval_aktif_menit, saldo_per_klaim, max_klaim, status, dibuat_oleh)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          [nama, jenis, deskripsi, gambarPath, harga, stok, durasi, interval, saldoKlaim, maxKlaim, statusProduk, session.id]
        );
        insertId = Number(result.insertId || 0);
      } catch (e1) {
        // fallback tanpa max_klaim / dibuat_oleh
        try {
          const result = await execute(
            `INSERT INTO produk
             (nama_produk, jenis_produk, deskripsi, gambar, harga, stok, durasi_aktif_menit, interval_aktif_menit, saldo_per_klaim, status)
             VALUES (?,?,?,?,?,?,?,?,?,?)`,
            [nama, jenis, deskripsi, gambarPath, harga, stok, durasi, interval, saldoKlaim, statusProduk]
          );
          insertId = Number(result.insertId || 0);
        } catch (e2) {
          const msg = e2 instanceof Error ? e2.message : String(e2);
          return NextResponse.json({ status: 'error', pesan: 'Gagal simpan produk: ' + msg });
        }
      }

      if (insertId > 0) {
        try {
          await execute(`UPDATE produk SET level_produk = ?, level_syarat = ?, max_beli_per_user = ? WHERE id = ?`, [levelProduk, levelSyarat, maxBeliPerUser, insertId]);
        } catch { /* kolom belum siap */ }
      }

      return NextResponse.json({
        status: 'sukses',
        pesan: statusProduk === 'aktif'
          ? 'Produk dibuat dan aktif.'
          : 'Produk dibuat sebagai draft. Publikasikan di Kelola Produk.',
        id: insertId,
      });
    }

    return NextResponse.json({ status: 'error', pesan: 'Aksi tidak dikenal' }, { status: 400 });
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ status: 'error', pesan: e.message }, { status: 401 });
    }
    const msg = e instanceof Error ? e.message : 'Server error';
    return NextResponse.json({ status: 'error', pesan: msg }, { status: 500 });
  }
}
