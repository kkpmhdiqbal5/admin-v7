import { NextResponse } from 'next/server';
import { clearAuthCookie } from '@/lib/auth';

export async function POST() {
  const res = NextResponse.json({ status: 'sukses', pesan: 'Logout berhasil' });
  clearAuthCookie(res);
  return res;
}
