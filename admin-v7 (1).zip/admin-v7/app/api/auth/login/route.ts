import { NextRequest, NextResponse } from 'next/server';
import { createToken, loginAdmin, setAuthCookie } from '@/lib/auth';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const username = String(body.username || '').trim();
    const password = String(body.password || '');

    if (!username || !password) {
      return NextResponse.json(
        { status: 'error', pesan: 'Username dan password wajib diisi' },
        { status: 400 }
      );
    }

    const result = await loginAdmin(username, password);
    if (!result.ok) {
      return NextResponse.json({ status: 'error', pesan: result.pesan }, { status: 401 });
    }

    const token = await createToken(result.session);
    const res = NextResponse.json({
      status: 'sukses',
      pesan: 'Login admin berhasil!',
      admin: {
        id: result.session.id,
        username: result.session.username,
        role: result.session.role,
      },
    });
    setAuthCookie(res, token);
    return res;
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Server error';
    return NextResponse.json({ status: 'error', pesan: msg }, { status: 500 });
  }
}
