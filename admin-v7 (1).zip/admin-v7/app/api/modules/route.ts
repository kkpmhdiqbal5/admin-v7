import { randomBytes } from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { requireAdmin } from '@/lib/adminAuth';
import { execute, query, RowDataPacket } from '@/lib/db';

export const runtime = 'nodejs';

async function getSetting(kunci: string) {
  const rows = await query<RowDataPacket[]>(`SELECT nilai FROM pengaturan_keuangan WHERE kunci = ? LIMIT 1`, [kunci]);
  return rows[0]?.nilai ?? null;
}
async function setSetting(kunci: string, nilai: string) {
  await execute(
    `INSERT INTO pengaturan_keuangan (kunci, nilai) VALUES (?, ?)
     ON DUPLICATE KEY UPDATE nilai = VALUES(nilai)`,
    [kunci, nilai]
  );
}

export async function GET(req: NextRequest) {
  try {
    await requireAdmin();
    const mod = req.nextUrl.searchParams.get('mod') || '';

    if (mod === 'fonnte' || mod === 'otp_api') {
      return NextResponse.json({
        status: 'sukses',
        data: {
          fonnte_token: await getSetting('fonnte_token'),
          fonnte_country: (await getSetting('fonnte_country')) || '62',
          fonnte_aktif: (await getSetting('fonnte_aktif')) || '1',
          otp_template: (await getSetting('otp_template')) || '*KODE VERIFIKASI (OTP)*\n\nKode OTP Anda adalah: *{kode}*\n\nJangan berikan kode ini kepada siapa pun.',
          smtp_host: await getSetting('smtp_host'),
          smtp_user: await getSetting('smtp_user'),
          smtp_pass: await getSetting('smtp_pass'),
          smtp_from: await getSetting('smtp_from'),
          email_otp_aktif: (await getSetting('email_otp_aktif')) || '0',
        },
      });
    }
    
    if (mod === 'api_list') {
      return NextResponse.json({
        status: 'sukses',
        data: await query(`SELECT * FROM api_gateway_list ORDER BY id DESC`),
      });
    }

    if (mod === 'redeem') {
      return NextResponse.json({
        status: 'sukses',
        data: await query(
          `SELECT k.*, u.username AS username_tujuan
           FROM kode_redeem k LEFT JOIN users u ON u.id = k.user_id
           ORDER BY k.id DESC LIMIT 100`
        ),
      });
    }
    if (mod === 'vip') {
      return NextResponse.json({ status: 'sukses', data: await query(`SELECT * FROM vip_level ORDER BY level ASC`) });
    }
    if (mod === 'referral') {
      const levels = await query(`SELECT * FROM pengaturan_referral ORDER BY level ASC`);
      const khusus = await query(
        `SELECT r.*, u.username FROM referral_khusus r LEFT JOIN users u ON u.id = r.user_id ORDER BY r.id DESC`
      );
      const stats = await query<RowDataPacket[]>(
        `SELECT
           (SELECT COUNT(DISTINCT referred_by) FROM users WHERE referred_by IS NOT NULL) AS member_upline,
           (SELECT COALESCE(SUM(total_komisi),0) FROM users) AS total_komisi`
      );
      return NextResponse.json({ status: 'sukses', levels, khusus, stats: stats[0] || {} });
    }
    if (mod === 'rekening') {
      return NextResponse.json({
        status: 'sukses',
        topup: await query(`SELECT * FROM rekening_topup ORDER BY urutan ASC, id ASC`),
        penarikan: await query(`SELECT * FROM metode_penarikan ORDER BY urutan ASC, id ASC`),
        mode_topup: await getSetting('mode_topup'),
        mode_penarikan: await getSetting('mode_penarikan'),
        gateway: {
          provider: await getSetting('gateway_provider'),
          mode: await getSetting('gateway_mode'),
          license_key: await getSetting('gateway_license_key'),
          webhook_secret: await getSetting('gateway_webhook_secret'),
          qris_id: await getSetting('gateway_qris_id'),
          server_key: await getSetting('gateway_server_key'),
          client_key: await getSetting('gateway_client_key'),
          merchant_id: await getSetting('gateway_merchant_id'),
          auto_webhook: await getSetting('gateway_auto_webhook'),
          crypto_provider: await getSetting('crypto_provider'),
          crypto_api_key: await getSetting('crypto_api_key'),
          crypto_ipn_secret: await getSetting('crypto_ipn_secret'),
          crypto_default_coin: await getSetting('crypto_default_coin') || 'USDT',
          crypto_default_network: await getSetting('crypto_default_network') || 'TRC20',
          crypto_auto_confirm: await getSetting('crypto_auto_confirm') || '0',
        },
      });
    }
    if (mod === 'checkin') {
      return NextResponse.json({
        status: 'sukses',
        aktif: (await getSetting('checkin_aktif')) !== '0',
        mode: (await getSetting('checkin_mode')) || 'statis',
        default_nominal: Number((await getSetting('checkin_default')) || 1000),
        hadiah: await query(`SELECT * FROM checkin_hadiah ORDER BY hari_ke ASC`),
      });
    }
    if (mod === 'subadmin') {
      return NextResponse.json({
        status: 'sukses',
        data: await query(`SELECT id, username, role, izin, status, created_at FROM admins ORDER BY id ASC`),
      });
    }
    if (mod === 'komunitas') {
      return NextResponse.json({
        status: 'sukses',
        data: await query(`SELECT * FROM komunitas_post ORDER BY id DESC LIMIT 50`),
      });
    }
    if (mod === 'chat_unread') {
      try {
        const rows = await query(
          `SELECT COUNT(DISTINCT user_id) AS clients,
                  COALESCE(SUM(CASE WHEN dibaca = 0 AND pengirim = 'user' THEN 1 ELSE 0 END),0) AS pesan
           FROM chat_messages
           WHERE dibaca = 0 AND pengirim = 'user'`
        );
        return NextResponse.json({
          status: 'sukses',
          clients: Number(rows[0]?.clients || 0),
          pesan: Number(rows[0]?.pesan || 0),
        });
      } catch {
        return NextResponse.json({ status: 'sukses', clients: 0, pesan: 0 });
      }
    }
    if (mod === 'chat_inbox') {
      const tab = String(req.nextUrl.searchParams.get('tab') || 'baru');
      // pastikan kolom chat_verifikasi ada
      try {
        await execute(`ALTER TABLE users ADD COLUMN chat_verifikasi VARCHAR(10) NOT NULL DEFAULT 'baru'`);
      } catch { /* already exists */ }

      let data: any[] = [];
      try {
        data = await query(
          `SELECT m.user_id, u.username, u.chat_verifikasi,
                  MAX(m.id) AS last_id,
                  MAX(m.created_at) AS last_at,
                  SUBSTRING_INDEX(GROUP_CONCAT(m.pesan ORDER BY m.id DESC SEPARATOR '|||'), '|||', 1) AS last_pesan,
                  SUM(CASE WHEN m.dibaca = 0 AND m.pengirim = 'user' THEN 1 ELSE 0 END) AS unread
           FROM chat_messages m
           LEFT JOIN users u ON u.id = m.user_id
           WHERE COALESCE(u.chat_verifikasi, 'baru') = ?
           GROUP BY m.user_id, u.username, u.chat_verifikasi
           ORDER BY last_at DESC LIMIT 80`,
          [tab === 'lama' ? 'lama' : 'baru']
        );
      } catch {
        data = await query(
          `SELECT m.user_id, u.username, MAX(m.created_at) AS last_at,
                  SUM(CASE WHEN m.dibaca = 0 AND m.pengirim = 'user' THEN 1 ELSE 0 END) AS unread
           FROM chat_messages m
           LEFT JOIN users u ON u.id = m.user_id
           GROUP BY m.user_id, u.username
           ORDER BY last_at DESC LIMIT 50`
        );
      }
      return NextResponse.json({ status: 'sukses', data });
    }
    if (mod === 'chat_thread') {
      const uid = Number(req.nextUrl.searchParams.get('user_id') || 0);
      const data = await query(`SELECT * FROM chat_messages WHERE user_id = ? ORDER BY id ASC LIMIT 100`, [uid]);
      await execute(`UPDATE chat_messages SET dibaca = 1 WHERE user_id = ? AND pengirim = 'user'`, [uid]);
      return NextResponse.json({ status: 'sukses', data });
    }
    if (mod === 'akun') {
      return NextResponse.json({
        status: 'sukses',
        data: await query(
          `SELECT id, id_user, username, email, no_hp, vip_level, status_akun, created_at
           FROM users ORDER BY id DESC LIMIT 200`
        ),
      });
    }
    if (mod === 'tampilan') {
      return NextResponse.json({
        status: 'sukses',
        data: {
          brand: (await getSetting('client_brand')) || 'V7 App',
          logo: (await getSetting('client_logo')) || '',
          primary: (await getSetting('client_primary')) || '#22c55e',
          bg: (await getSetting('client_bg')) || '#050505',
          text: (await getSetting('client_text')) || '#ffffff',
          muted: (await getSetting('client_muted')) || '#888888',
          button: (await getSetting('client_button')) || (await getSetting('client_primary')) || '#22c55e',
          button_text: (await getSetting('client_button_text')) || '#000000',
          card: (await getSetting('client_card')) || '#121212',
          border: (await getSetting('client_border')) || '#333333',
          bg_image: (await getSetting('client_bg_image')) || '',
          overlay: (await getSetting('client_overlay')) || '0.65',
          login_bg: (await getSetting('client_login_bg')) || '',
          dashboard_accent: (await getSetting('client_dashboard_accent')) || '',
          topup_accent: (await getSetting('client_topup_accent')) || '',
          produk_accent: (await getSetting('client_produk_accent')) || '',
          success: (await getSetting('client_success')) || '#22c55e',
          danger: (await getSetting('client_danger')) || '#dc3545',
          warning: (await getSetting('client_warning')) || '#facc15',
          radius: (await getSetting('client_radius')) || '14',
          font_size: (await getSetting('client_font_size')) || '14',
          nav_bg: (await getSetting('client_nav_bg')) || '#0a0a0a',
          input_bg: (await getSetting('client_input_bg')) || '#111111',
        },
      });
    }

    return NextResponse.json({ status: 'error', pesan: 'mod tidak dikenal' }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ status: 'error', pesan: e instanceof Error ? e.message : 'Error' }, { status: 401 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const admin = await requireAdmin();
    const ct = req.headers.get('content-type') || '';
    let body: Record<string, any> = {};
    let uploadFile: { buffer: Buffer; mime: string; name: string } | null = null;

    if (ct.includes('multipart/form-data')) {
      const form = await req.formData();
      form.forEach((v, k) => {
        if (k === 'file' && v instanceof File) {
          /* handled below */
        } else {
          body[k] = typeof v === 'string' ? v : String(v);
        }
      });
      const f = form.get('file');
      if (f instanceof File && f.size > 0) {
        uploadFile = {
          buffer: Buffer.from(await f.arrayBuffer()),
          mime: f.type || 'application/octet-stream',
          name: f.name || 'file',
        };
      }
    } else {
      body = await req.json();
    }

    const mod = String(body.mod || '');
    const aksi = String(body.aksi || '');

    // REDEEM — untuk user tertentu (sesuai PHP)
    if (mod === 'redeem' && aksi === 'buat') {
      const username = String(body.username || '').trim();
      const nominal = Number(body.nominal || 0);
      const tipe = body.tipe_saldo === 'dompet' ? 'dompet' : 'deposit';
      if (!username || nominal <= 0) return NextResponse.json({ status: 'error', pesan: 'Username & nominal wajib' });
      const users = await query<RowDataPacket[]>(`SELECT id FROM users WHERE username = ? OR id_user = ? LIMIT 1`, [username, username]);
      if (!users[0]) return NextResponse.json({ status: 'error', pesan: 'User tidak ditemukan' });
      const kode = 'RD' + Math.random().toString(36).slice(2, 8).toUpperCase() + Date.now().toString().slice(-4);
      await execute(
        `INSERT INTO kode_redeem (kode, user_id, tipe_saldo, nominal, status, dibuat_oleh) VALUES (?, ?, ?, ?, 'aktif', ?)`,
        [kode, users[0].id, tipe, nominal, admin.id]
      );
      return NextResponse.json({ status: 'sukses', pesan: `Kode dibuat: ${kode}`, kode });
    }
    if (mod === 'redeem' && aksi === 'nonaktif') {
      await execute(`UPDATE kode_redeem SET status = 'kadaluarsa' WHERE id = ?`, [Number(body.id)]);
      return NextResponse.json({ status: 'sukses', pesan: 'Kode dinonaktifkan' });
    }

    // VIP — simpan semua level
    if (mod === 'vip' && aksi === 'simpan_batch') {
      const items = Array.isArray(body.items) ? body.items : [];
      for (const it of items) {
        const level = Number(it.level);
        const nama = String(it.nama || `VIP${level}`);
        const min_anggota = Number(it.min_anggota || 0);
        const min_belanja = Number(it.min_belanja || 0);
        const exist = await query<RowDataPacket[]>(`SELECT id FROM vip_level WHERE level = ?`, [level]);
        if (exist[0]) {
          await execute(`UPDATE vip_level SET nama=?, min_anggota=?, min_belanja=? WHERE level=?`, [
            nama, min_anggota, min_belanja, level,
          ]);
        } else {
          await execute(`INSERT INTO vip_level (level, nama, min_anggota, min_belanja) VALUES (?,?,?,?)`, [
            level, nama, min_anggota, min_belanja,
          ]);
        }
      }
      return NextResponse.json({ status: 'sukses', pesan: 'VIP disimpan' });
    }

    // REFERRAL
    if (mod === 'referral' && aksi === 'simpan_levels') {
      const items = Array.isArray(body.items) ? body.items : [];
      for (const it of items) {
        const level = Number(it.level);
        const persen = Number(it.persen || 0);
        const exist = await query<RowDataPacket[]>(`SELECT id FROM pengaturan_referral WHERE level = ?`, [level]);
        if (exist[0]) await execute(`UPDATE pengaturan_referral SET persen = ? WHERE level = ?`, [persen, level]);
        else await execute(`INSERT INTO pengaturan_referral (level, persen) VALUES (?, ?)`, [level, persen]);
      }
      return NextResponse.json({ status: 'sukses', pesan: 'Persentase referral disimpan' });
    }
    if (mod === 'referral' && aksi === 'simpan_khusus') {
      const username = String(body.username || '').trim();
      const users = await query<RowDataPacket[]>(`SELECT id FROM users WHERE username = ? OR id_user = ? LIMIT 1`, [username, username]);
      if (!users[0]) return NextResponse.json({ status: 'error', pesan: 'User tidak ditemukan' });
      await execute(
        `INSERT INTO referral_khusus (user_id, persen_level1, persen_level2, persen_level3, aktif)
         VALUES (?, ?, ?, ?, 1)
         ON DUPLICATE KEY UPDATE persen_level1=VALUES(persen_level1), persen_level2=VALUES(persen_level2), persen_level3=VALUES(persen_level3), aktif=1`,
        [users[0].id, Number(body.l1 || 0), Number(body.l2 || 0), Number(body.l3 || 0)]
      );
      return NextResponse.json({ status: 'sukses', pesan: 'Referral khusus disimpan' });
    }

    // REKENING / GATEWAY
    if (mod === 'rekening' && aksi === 'simpan_topup') {
      try { await execute(`ALTER TABLE rekening_topup ADD COLUMN network VARCHAR(32) NULL`); } catch {}
      try { await execute(`ALTER TABLE rekening_topup ADD COLUMN coin VARCHAR(16) NULL`); } catch {}
      const id = Number(body.id || 0);
      const tipe = String(body.tipe || 'transfer');
      if (id) {
        await execute(
          `UPDATE rekening_topup SET tipe=?, bank_nama=?, no_rekening=?, atas_nama=?, network=?, coin=?, aktif=?, auto_konfirmasi=?, urutan=? WHERE id=?`,
          [tipe, body.bank_nama || '', body.no_rekening || '', body.atas_nama || '', body.network || '', body.coin || '', body.aktif === 0 ? 0 : 1, body.auto_konfirmasi ? 1 : 0, Number(body.urutan || 0), id]
        );
      } else {
        await execute(
          `INSERT INTO rekening_topup (tipe, bank_nama, no_rekening, atas_nama, network, coin, aktif, auto_konfirmasi, urutan) VALUES (?,?,?,?,?,?,?,?,?)`,
          [tipe, body.bank_nama || '', body.no_rekening || '', body.atas_nama || '', body.network || '', body.coin || '', 1, body.auto_konfirmasi ? 1 : 0, Number(body.urutan || 0)]
        );
      }
      return NextResponse.json({ status: 'sukses', pesan: 'Metode top up disimpan' });
    }
    if (mod === 'rekening' && aksi === 'hapus_topup') {
      await execute(`DELETE FROM rekening_topup WHERE id = ?`, [Number(body.id)]);
      return NextResponse.json({ status: 'sukses', pesan: 'Dihapus' });
    }
    if (mod === 'rekening' && aksi === 'simpan_penarikan') {
      await execute(
        `INSERT INTO metode_penarikan (kode, nama, tipe, aktif, urutan) VALUES (?, ?, ?, 1, ?)
         ON DUPLICATE KEY UPDATE nama=VALUES(nama), tipe=VALUES(tipe), aktif=1, urutan=VALUES(urutan)`,
        [String(body.kode || body.nama || '').toLowerCase().replace(/\s+/g, ''), body.nama, body.tipe || 'bank', Number(body.urutan || 0)]
      );
      return NextResponse.json({ status: 'sukses', pesan: 'Metode penarikan ditambah' });
    }
    if (mod === 'rekening' && aksi === 'toggle_penarikan') {
      await execute(`UPDATE metode_penarikan SET aktif = ? WHERE id = ?`, [body.aktif ? 1 : 0, Number(body.id)]);
      return NextResponse.json({ status: 'sukses', pesan: 'Status diubah' });
    }
    if (mod === 'rekening' && aksi === 'simpan_mode') {
      await setSetting('mode_topup', String(body.mode_topup || 'manual'));
      await setSetting('mode_penarikan', String(body.mode_penarikan || 'manual'));
      return NextResponse.json({ status: 'sukses', pesan: 'Mode konfirmasi disimpan' });
    }
    if (mod === 'rekening' && aksi === 'simpan_crypto_gateway') {
      await setSetting('crypto_provider', String(body.crypto_provider || ''));
      await setSetting('crypto_api_key', String(body.crypto_api_key || ''));
      await setSetting('crypto_ipn_secret', String(body.crypto_ipn_secret || ''));
      await setSetting('crypto_default_coin', String(body.crypto_default_coin || 'USDT'));
      await setSetting('crypto_default_network', String(body.crypto_default_network || 'TRC20'));
      await setSetting('crypto_auto_confirm', body.crypto_auto_confirm ? '1' : '0');
      return NextResponse.json({ status: 'sukses', pesan: 'Crypto gateway disimpan' });
    }
    if (mod === 'rekening' && aksi === 'simpan_gateway') {
      await setSetting('gateway_provider', String(body.provider || ''));
      await setSetting('gateway_mode', String(body.mode || 'production'));
      await setSetting('gateway_license_key', String(body.license_key || ''));
      await setSetting('gateway_webhook_secret', String(body.webhook_secret || ''));
      await setSetting('gateway_qris_id', String(body.qris_id || ''));
      await setSetting('gateway_server_key', String(body.server_key || ''));
      await setSetting('gateway_client_key', String(body.client_key || ''));
      await setSetting('gateway_merchant_id', String(body.merchant_id || ''));
      await setSetting('gateway_auto_webhook', body.auto_webhook ? '1' : '0');
      return NextResponse.json({ status: 'sukses', pesan: 'Parameter gateway disimpan' });
    }

    // CHECKIN
    if (mod === 'checkin' && aksi === 'simpan_pengaturan') {
      await setSetting('checkin_aktif', body.aktif ? '1' : '0');
      await setSetting('checkin_mode', body.mode === 'bertahap' ? 'bertahap' : 'statis');
      await setSetting('checkin_default', String(Number(body.default_nominal || 1000)));
      return NextResponse.json({ status: 'sukses', pesan: 'Pengaturan check-in disimpan' });
    }
    if (mod === 'checkin' && aksi === 'simpan_hadiah') {
      const items = Array.isArray(body.items) ? body.items : [];
      for (const it of items) {
        const hari = Number(it.hari_ke);
        const nominal = Number(it.nominal || 0);
        const tipe = ['deposit', 'dompet', 'poin'].includes(it.tipe_saldo) ? it.tipe_saldo : 'dompet';
        const exist = await query<RowDataPacket[]>(`SELECT id FROM checkin_hadiah WHERE hari_ke = ?`, [hari]);
        if (exist[0]) await execute(`UPDATE checkin_hadiah SET nominal=?, tipe_saldo=?, aktif=1 WHERE hari_ke=?`, [nominal, tipe, hari]);
        else await execute(`INSERT INTO checkin_hadiah (hari_ke, nominal, tipe_saldo, aktif) VALUES (?,?,?,1)`, [hari, nominal, tipe]);
      }
      return NextResponse.json({ status: 'sukses', pesan: 'Hadiah bertahap disimpan' });
    }

    // SUBADMIN with permissions
    if (mod === 'subadmin' && aksi === 'buat') {
      const username = String(body.username || '').trim();
      const password = String(body.password || '');
      const izin = Array.isArray(body.izin) ? body.izin : [];
      if (!username || password.length < 6) return NextResponse.json({ status: 'error', pesan: 'Username & password min 6' });
      const hash = await bcrypt.hash(password, 10);
      await execute(
        `INSERT INTO admins (username, password, role, izin, status, dibuat_oleh) VALUES (?, ?, 'sub_admin', ?, 'aktif', ?)`,
        [username, hash, JSON.stringify(izin), admin.id]
      );
      return NextResponse.json({ status: 'sukses', pesan: 'Sub-admin dibuat' });
    }
    if (mod === 'subadmin' && aksi === 'nonaktif') {
      await execute(`UPDATE admins SET status = 'nonaktif' WHERE id = ? AND role = 'sub_admin'`, [Number(body.id)]);
      return NextResponse.json({ status: 'sukses', pesan: 'Sub-admin nonaktif' });
    }

    // KOMUNITAS — admin only post
    if (mod === 'komunitas' && aksi === 'posting') {
      const isi = String(body.isi || '').trim();
      let media_url = String(body.media_url || '').trim();
      let media_type = ['gambar', 'video'].includes(String(body.media_type)) ? String(body.media_type) : '';
      if (uploadFile) {
        const isImg = uploadFile.mime.startsWith('image/');
        const isVid = uploadFile.mime.startsWith('video/');
        if (!isImg && !isVid) {
          return NextResponse.json({ status: 'error', pesan: 'File harus gambar atau video' });
        }
        if (uploadFile.buffer.length > 25 * 1024 * 1024) {
          return NextResponse.json({ status: 'error', pesan: 'File maksimal 25MB' });
        }
        media_type = isImg ? 'gambar' : 'video';
        const ext = (uploadFile.name.split('.').pop() || (isImg ? 'jpg' : 'mp4')).toLowerCase();
        const path = `komunitas/${Date.now()}_${randomBytes(4).toString('hex')}.${ext}`;
        const up = await supabaseUpload(uploadFile.buffer, path, uploadFile.mime);
        if (!up.ok) {
          return NextResponse.json({ status: 'error', pesan: 'Upload gagal: ' + up.error });
        }
        media_url = up.url;
      }
      if (!isi && !media_url) return NextResponse.json({ status: 'error', pesan: 'Teks atau media wajib' });
      try {
        await execute(
          `INSERT INTO komunitas_post (user_id, isi, media_url, media_type, created_at) VALUES (NULL, ?, ?, ?, NOW())`,
          [isi || '', media_url || null, media_type || null]
        );
      } catch {
        try {
          await execute(`INSERT INTO komunitas_post (isi, media_url, media_type) VALUES (?,?,?)`, [isi || '', media_url || null, media_type || null]);
        } catch {
          await execute(`INSERT INTO komunitas_post (isi) VALUES (?)`, [isi || '']);
        }
      }
      return NextResponse.json({ status: 'sukses', pesan: 'Posting berhasil' });
    }
    if (mod === 'komunitas' && aksi === 'hapus') {
      await execute(`DELETE FROM komunitas_post WHERE id = ?`, [Number(body.id)]);
      return NextResponse.json({ status: 'sukses', pesan: 'Post dihapus' });
    }

    // CHAT
    if (mod === 'chat' && aksi === 'verifikasi') {
      const user_id = Number(body.user_id || 0);
      if (!user_id) return NextResponse.json({ status: 'error', pesan: 'user_id wajib' });
      try {
        await execute(`ALTER TABLE users ADD COLUMN chat_verifikasi VARCHAR(10) NOT NULL DEFAULT 'baru'`);
      } catch { /* */ }
      await execute(`UPDATE users SET chat_verifikasi = 'lama' WHERE id = ?`, [user_id]);
      return NextResponse.json({ status: 'sukses', pesan: 'Client dipindah ke Client Lama (terverifikasi)' });
    }
    if (mod === 'chat' && aksi === 'batal_verifikasi') {
      const user_id = Number(body.user_id || 0);
      if (!user_id) return NextResponse.json({ status: 'error', pesan: 'user_id wajib' });
      await execute(`UPDATE users SET chat_verifikasi = 'baru' WHERE id = ?`, [user_id]);
      return NextResponse.json({ status: 'sukses', pesan: 'Client dikembalikan ke Client Baru' });
    }
    if (mod === 'chat' && aksi === 'balas') {
      const user_id = Number(body.user_id || 0);
      let pesan = String(body.pesan || '').trim();
      let media_url = String(body.media_url || '').trim();
      let media_type = String(body.media_type || '').trim();
      if (uploadFile && user_id) {
        const isImg = uploadFile.mime.startsWith('image/');
        const isVid = uploadFile.mime.startsWith('video/');
        if (!isImg && !isVid) return NextResponse.json({ status: 'error', pesan: 'File harus gambar/video' });
        if (uploadFile.buffer.length > 25 * 1024 * 1024) return NextResponse.json({ status: 'error', pesan: 'File max 25MB' });
        media_type = isImg ? 'gambar' : 'video';
        const ext = (uploadFile.name.split('.').pop() || (isImg ? 'jpg' : 'mp4')).toLowerCase();
        const path = `chat/admin_${Date.now()}_${randomBytes(3).toString('hex')}.${ext}`;
        const up = await supabaseUpload(uploadFile.buffer, path, uploadFile.mime);
        if (!up.ok) return NextResponse.json({ status: 'error', pesan: 'Upload gagal: ' + up.error });
        media_url = up.url;
      }
      if (!user_id || (!pesan && !media_url)) return NextResponse.json({ status: 'error', pesan: 'Data kurang' });
      try {
        try {
          await execute(`ALTER TABLE chat_messages ADD COLUMN admin_nama VARCHAR(64) NULL`);
        } catch { /* exists */ }
        try {
          await execute(
            `INSERT INTO chat_messages (user_id, pengirim, pesan, media_url, media_type, dibaca, admin_nama) VALUES (?, 'admin', ?, ?, ?, 0, ?)`,
            [user_id, pesan || '', media_url || null, media_type || null, admin.username || 'Admin']
          );
        } catch {
          await execute(
            `INSERT INTO chat_messages (user_id, pengirim, pesan, media_url, media_type, dibaca) VALUES (?, 'admin', ?, ?, ?, 0)`,
            [user_id, pesan || '', media_url || null, media_type || null]
          );
        }
      } catch {
        await execute(`INSERT INTO chat_messages (user_id, pengirim, pesan, dibaca) VALUES (?, 'admin', ?, 0)`, [user_id, pesan || media_url || '(media)']);
      }
      return NextResponse.json({ status: 'sukses', pesan: 'Terkirim' });
    }

    // AKUN — hanya VIP & status (sesuai PHP: saldo lewat redeem)
    if (mod === 'akun' && aksi === 'simpan') {
      const vip = String(body.vip_level || 'VIP1');
      const status = ['aktif', 'nonaktif', 'banned'].includes(body.status_akun) ? body.status_akun : 'aktif';
      await execute(`UPDATE users SET vip_level = ?, status_akun = ? WHERE id = ?`, [vip, status, Number(body.id)]);
      return NextResponse.json({ status: 'sukses', pesan: 'Akun berhasil diperbarui (non-finansial).' });
    }

    // TAMPILAN
    if (mod === 'tampilan' && aksi === 'simpan') {
      const map: Record<string, string> = {
        client_brand: String(body.brand || 'V7 App'),
        client_logo: String(body.logo || ''),
        client_primary: String(body.primary || '#22c55e'),
        client_bg: String(body.bg || '#050505'),
        client_text: String(body.text || '#ffffff'),
        client_muted: String(body.muted || '#888888'),
        client_button: String(body.button || body.primary || '#22c55e'),
        client_button_text: String(body.button_text || '#000000'),
        client_card: String(body.card || '#121212'),
        client_border: String(body.border || '#333333'),
        client_bg_image: String(body.bg_image || ''),
        client_overlay: String(body.overlay || '0.65'),
        client_login_bg: String(body.login_bg || ''),
        client_dashboard_accent: String(body.dashboard_accent || ''),
        client_topup_accent: String(body.topup_accent || ''),
        client_produk_accent: String(body.produk_accent || ''),
        client_success: String(body.success || '#22c55e'),
        client_danger: String(body.danger || '#dc3545'),
        client_warning: String(body.warning || '#facc15'),
        client_radius: String(body.radius || '14'),
        client_font_size: String(body.font_size || '14'),
        client_nav_bg: String(body.nav_bg || '#0a0a0a'),
        client_input_bg: String(body.input_bg || '#111111'),
      };
      for (const [k, v] of Object.entries(map)) await setSetting(k, v);
      return NextResponse.json({ status: 'sukses', pesan: 'Tampilan client disimpan' });
    }

    
    // FONNTE / OTP API
    if ((mod === 'fonnte' || mod === 'otp_api') && aksi === 'simpan') {
      await setSetting('fonnte_token', String(body.fonnte_token || '').trim());
      await setSetting('fonnte_country', String(body.fonnte_country || '62').trim());
      await setSetting('fonnte_aktif', body.fonnte_aktif === '0' || body.fonnte_aktif === false ? '0' : '1');
      await setSetting('otp_template', String(body.otp_template || '').trim());
      await setSetting('smtp_host', String(body.smtp_host || '').trim());
      await setSetting('smtp_user', String(body.smtp_user || '').trim());
      if (body.smtp_pass !== undefined && String(body.smtp_pass) !== '') {
        await setSetting('smtp_pass', String(body.smtp_pass).trim());
      }
      await setSetting('smtp_from', String(body.smtp_from || '').trim());
      await setSetting('email_otp_aktif', body.email_otp_aktif === '1' || body.email_otp_aktif === true ? '1' : '0');
      return NextResponse.json({ status: 'sukses', pesan: 'Pengaturan Fonnte / OTP disimpan' });
    }
    if ((mod === 'fonnte' || mod === 'otp_api') && aksi === 'tes') {
      const token = String(body.fonnte_token || (await getSetting('fonnte_token')) || '').trim();
      const target = String(body.target || '').replace(/\D/g, '');
      if (!token) return NextResponse.json({ status: 'error', pesan: 'Token Fonnte kosong' });
      if (!target) return NextResponse.json({ status: 'error', pesan: 'Nomor tujuan tes wajib' });
      const country = String(body.fonnte_country || (await getSetting('fonnte_country')) || '62');
      const form = new URLSearchParams();
      form.set('target', target);
      form.set('message', 'Tes kirim dari Admin V7 — Fonnte OK');
      form.set('countryCode', country);
      const res = await fetch('https://api.fonnte.com/send', {
        method: 'POST',
        headers: { Authorization: token },
        body: form,
      });
      const text = await res.text();
      let json: any = null;
      try { json = JSON.parse(text); } catch {}
      const ok = res.ok && (json?.status === true || json?.status === 'true' || !json?.reason);
      return NextResponse.json({
        status: ok ? 'sukses' : 'error',
        pesan: ok ? 'Pesan tes terkirim' : ('Gagal: ' + (json?.reason || text.slice(0, 200))),
        raw: json || text.slice(0, 300),
      });
    }


    
    if (mod === 'vip' && aksi === 'simpan_semua') {
      const levels = Array.isArray(body.levels) ? body.levels : [];
      for (const L of levels) {
        const level = Number(L.level || 0);
        const nama = String(L.nama || `VIP${level}`);
        const min_anggota = Number(L.min_anggota || 0);
        const min_belanja = Number(L.min_belanja || 0);
        if (level <= 0) continue;
        const exist = await query<RowDataPacket[]>(`SELECT id FROM vip_level WHERE level = ? LIMIT 1`, [level]);
        if (exist[0]) {
          try {
            await execute(`UPDATE vip_level SET nama = ?, min_anggota = ?, min_belanja = ? WHERE level = ?`, [nama, min_anggota, min_belanja, level]);
          } catch {
            await execute(`UPDATE vip_level SET nama_level = ?, min_member = ?, min_spending = ? WHERE level = ?`, [nama, min_anggota, min_belanja, level]);
          }
        } else {
          try {
            await execute(`INSERT INTO vip_level (level, nama, min_anggota, min_belanja) VALUES (?,?,?,?)`, [level, nama, min_anggota, min_belanja]);
          } catch {
            await execute(`INSERT INTO vip_level (level, nama_level, min_member, min_spending) VALUES (?,?,?,?)`, [level, nama, min_anggota, min_belanja]);
          }
        }
      }
      return NextResponse.json({ status: 'sukses', pesan: 'Tingkat VIP disimpan' });
    }

    
    // DAFTAR API GATEWAY
    if (mod === 'api_list' && aksi === 'simpan') {
      const id = Number(body.id || 0);
      const nama = String(body.nama || '').trim();
      const provider = String(body.provider || '').trim();
      if (!nama || !provider) return NextResponse.json({ status: 'error', pesan: 'Nama & provider wajib' });
      if (id > 0) {
        await execute(
          `UPDATE api_gateway_list SET nama=?, provider=?, api_key=?, api_secret=?, merchant_id=?, webhook_url=?, mode=?, aktif=?, catatan=? WHERE id=?`,
          [nama, provider, body.api_key || '', body.api_secret || '', body.merchant_id || '', body.webhook_url || '', body.mode || 'production', body.aktif === 0 || body.aktif === '0' ? 0 : 1, body.catatan || '', id]
        );
      } else {
        await execute(
          `INSERT INTO api_gateway_list (nama, provider, api_key, api_secret, merchant_id, webhook_url, mode, aktif, catatan) VALUES (?,?,?,?,?,?,?,?,?)`,
          [nama, provider, body.api_key || '', body.api_secret || '', body.merchant_id || '', body.webhook_url || '', body.mode || 'production', 1, body.catatan || '']
        );
      }
      return NextResponse.json({ status: 'sukses', pesan: 'API disimpan' });
    }
    if (mod === 'api_list' && aksi === 'toggle') {
      await execute(`UPDATE api_gateway_list SET aktif = ? WHERE id = ?`, [body.aktif ? 1 : 0, Number(body.id)]);
      return NextResponse.json({ status: 'sukses', pesan: body.aktif ? 'API diaktifkan' : 'API dinonaktifkan' });
    }
    if (mod === 'api_list' && aksi === 'hapus') {
      await execute(`DELETE FROM api_gateway_list WHERE id = ?`, [Number(body.id)]);
      return NextResponse.json({ status: 'sukses', pesan: 'API dihapus' });
    }


    
    if (mod === 'checkin' && aksi === 'simpan') {
      await setSetting('checkin_bonus', String(body.bonus || '1000'));
      await setSetting('checkin_jam_mulai', String(body.jam_mulai || '00:00'));
      await setSetting('checkin_jam_selesai', String(body.jam_selesai || '23:59'));
      return NextResponse.json({ status: 'sukses', pesan: 'Pengaturan check-in disimpan' });
    }
    if (mod === 'akun' && aksi === 'buka_kunci') {
      const user_id = Number(body.user_id || 0);
      const field = String(body.field || '');
      if (!user_id || !field) return NextResponse.json({ status: 'error', pesan: 'Data kurang' });
      // buka kunci field: email, no_hp, username, penarikan
      if (field === 'email') await execute(`UPDATE users SET email = NULL WHERE id = ?`, [user_id]);
      else if (field === 'no_hp' || field === 'hp') await execute(`UPDATE users SET no_hp = NULL WHERE id = ?`, [user_id]);
      else if (field === 'penarikan') await execute(`UPDATE users SET nama_ktp = NULL, nama_bank = NULL, no_rekening = NULL WHERE id = ?`, [user_id]);
      else if (field === 'username') {
        try { await execute(`UPDATE users SET username_diubah = 0 WHERE id = ?`, [user_id]); }
        catch { /* */ }
      }
      else return NextResponse.json({ status: 'error', pesan: 'Field tidak dikenal' });
      return NextResponse.json({ status: 'sukses', pesan: `Kunci ${field} dibuka — client bisa set ulang dengan OTP` });
    }

return NextResponse.json({ status: 'error', pesan: 'Aksi tidak dikenal' }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ status: 'error', pesan: e instanceof Error ? e.message : 'Error' }, { status: 500 });
  }
}
