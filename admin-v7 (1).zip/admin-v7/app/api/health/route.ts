import { NextResponse } from 'next/server';
import { supabasePing } from '@/lib/supabase';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const supabase = await supabasePing();
  return NextResponse.json({
    status: supabase.ok ? 'ok' : 'warn',
    db: {
      host: process.env.DB_HOST ? 'set' : 'missing',
      port: process.env.DB_PORT || '',
      name: process.env.DB_NAME || '',
    },
    supabase,
    jwt: process.env.JWT_SECRET ? 'set' : 'missing',
    time: new Date().toISOString(),
  });
}
