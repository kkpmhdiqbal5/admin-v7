import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { jwtVerify } from 'jose';
import { execute, query, RowDataPacket } from '@/lib/db';

export const runtime = 'nodejs';

async function requireAdmin() {
  const jar = await cookies();
  const t = jar.get('v7_admin_token')?.value;
  if (!t || !process.env.JWT_SECRET) throw new Error('Unauthorized');
  const { payload } = await jwtVerify(t, new TextEncoder().encode(process.env.JWT_SECRET));
  return { id: Number(payload.id) };
}

async function getSetting(kunci: string) {
  try {
    const rows = await query<RowDataPacket[]>(
      `SELECT nilai FROM pengaturan_keuangan WHERE kunci = ? LIMIT 1`,
      [kunci]
    );
    return rows[0]?.nilai != null ? String(rows[0].nilai) : null;
  } catch {
    return null;
  }
}

async function setSetting(kunci: string, nilai: string) {
  try {
    await execute(
      `INSERT INTO pengaturan_keuangan (kunci, nilai) VALUES (?, ?)
       ON DUPLICATE KEY UPDATE nilai = VALUES(nilai)`,
      [kunci, nilai]
    );
  } catch {
    try {
      await execute(`UPDATE pengaturan_keuangan SET nilai = ? WHERE kunci = ?`, [nilai, kunci]);
    } catch {
      /* */
    }
  }
}

export async function GET(req: NextRequest) {
  try {
    await requireAdmin();
    const sp = req.nextUrl.searchParams;
    const dari = sp.get('dari') || '';
    const sampai = sp.get('sampai') || '';
    const status = sp.get('status') || '';

    let sql = `SELECT p.*, u.username, u.nama_ktp, u.nama_bank, u.no_rekening, u.no_hp, u.email
       FROM penarikan_request p
       LEFT JOIN users u ON u.id = p.user_id
       WHERE 1=1`;
    const params: (string | number)[] = [];
    if (dari) {
      sql += ` AND DATE(p.created_at) >= ?`;
      params.push(dari);
    }
    if (sampai) {
      sql += ` AND DATE(p.created_at) <= ?`;
      params.push(sampai);
    }
    if (status) {
      sql += ` AND p.status = ?`;
      params.push(status);
    }
    sql += ` ORDER BY p.id DESC LIMIT 300`;

    const rows = await query<RowDataPacket[]>(sql, params);
    const settings = {
      min_tarik: Number((await getSetting('min_tarik')) || 10000),
      fee_persen: Number((await getSetting('tarik_fee_persen')) || 0),
      fee_tetap: Number((await getSetting('tarik_fee_tetap')) || 0),
      mode_penarikan: (await getSetting('mode_penarikan')) || 'manual',
      payment_out_provider: (await getSetting('payment_out_provider')) || '',
      payment_out_key: (await getSetting('payment_out_key')) || '',
      payment_out_auto: (await getSetting('payment_out_auto')) || '0',
    };
    return NextResponse.json({ status: 'sukses', data: rows, settings });
  } catch (e) {
    return NextResponse.json({ status: 'error', pesan: e instanceof Error ? e.message : 'Error' }, { status: 401 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const admin = await requireAdmin();
    const body = await req.json();
    const aksi = String(body.aksi || '');

    if (aksi === 'simpan_setting') {
      await setSetting('min_tarik', String(Number(body.min_tarik) || 10000));
      await setSetting('tarik_fee_persen', String(Number(body.fee_persen) || 0));
      await setSetting('tarik_fee_tetap', String(Number(body.fee_tetap) || 0));
      await setSetting('mode_penarikan', String(body.mode_penarikan || 'manual'));
      await setSetting('payment_out_provider', String(body.payment_out_provider || ''));
      await setSetting('payment_out_key', String(body.payment_out_key || ''));
      await setSetting('payment_out_auto', body.payment_out_auto ? '1' : '0');
      return NextResponse.json({ status: 'sukses', pesan: 'Pengaturan penarikan disimpan' });
    }

    // bulk berhasil / ditolak
    if (aksi === 'bulk' && Array.isArray(body.ids)) {
      const ids = body.ids.map(Number).filter(Boolean);
      const statusAksi = String(body.status_aksi || '');
      let n = 0;
      for (const id of ids) {
        const rows = await query<RowDataPacket[]>(`SELECT * FROM penarikan_request WHERE id = ? LIMIT 1`, [id]);
        const p = rows[0];
        if (!p || p.status !== 'menunggu') continue;
        if (statusAksi === 'ditolak') {
          await execute(`UPDATE users SET dompet_saldo = dompet_saldo + ? WHERE id = ?`, [
            Number(p.nominal),
            p.user_id,
          ]);
          await execute(
            `UPDATE penarikan_request SET status = 'ditolak', diproses_oleh = ?, diproses_at = NOW() WHERE id = ?`,
            [admin.id, id]
          );
          n++;
        } else if (statusAksi === 'berhasil') {
          await execute(
            `UPDATE penarikan_request SET status = 'berhasil', diproses_oleh = ?, diproses_at = NOW() WHERE id = ?`,
            [admin.id, id]
          );
          try {
            await execute(`UPDATE users SET total_penarikan = COALESCE(total_penarikan,0) + ? WHERE id = ?`, [
              Number(p.nominal),
              p.user_id,
            ]);
          } catch {
            /* */
          }
          n++;
        }
      }
      return NextResponse.json({ status: 'sukses', pesan: `${n} penarikan diproses` });
    }

    // gateway auto confirm after "dikirim"
    if (aksi === 'kirim_gateway') {
      const id = Number(body.id || 0);
      const rows = await query<RowDataPacket[]>(`SELECT * FROM penarikan_request WHERE id = ? LIMIT 1`, [id]);
      const p = rows[0];
      if (!p || p.status !== 'menunggu') {
        return NextResponse.json({ status: 'error', pesan: 'Request tidak valid' });
      }
      // Placeholder: integrasi payment-out gateway
      // Saat auto ON → langsung konfirmasi berhasil
      const auto = (await getSetting('payment_out_auto')) === '1';
      if (auto) {
        await execute(
          `UPDATE penarikan_request SET status = 'berhasil', diproses_oleh = ?, diproses_at = NOW(), catatan = 'auto gateway' WHERE id = ?`,
          [admin.id, id]
        );
        try {
          await execute(`UPDATE users SET total_penarikan = COALESCE(total_penarikan,0) + ? WHERE id = ?`, [
            Number(p.nominal),
            p.user_id,
          ]);
        } catch {
          /* */
        }
        return NextResponse.json({
          status: 'sukses',
          pesan: 'Dikirim via gateway & dikonfirmasi otomatis',
        });
      }
      await execute(
        `UPDATE penarikan_request SET status = 'diproses', diproses_oleh = ?, diproses_at = NOW(), catatan = 'gateway pending' WHERE id = ?`,
        [admin.id, id]
      );
      return NextResponse.json({
        status: 'sukses',
        pesan: 'Dikirim ke gateway (menunggu callback). Aktifkan auto-konfirmasi di setting bila perlu.',
      });
    }

    const id = Number(body.id || 0);
    const statusAksi = String(body.aksi || '');
    if (!id || !['berhasil', 'ditolak'].includes(statusAksi)) {
      return NextResponse.json({ status: 'error', pesan: 'Data tidak valid' });
    }

    const rows = await query<RowDataPacket[]>(`SELECT * FROM penarikan_request WHERE id = ? LIMIT 1`, [id]);
    const p = rows[0];
    if (!p || p.status !== 'menunggu') {
      return NextResponse.json({ status: 'error', pesan: 'Request tidak valid' });
    }

    if (statusAksi === 'ditolak') {
      await execute(`UPDATE users SET dompet_saldo = dompet_saldo + ? WHERE id = ?`, [Number(p.nominal), p.user_id]);
      await execute(
        `UPDATE penarikan_request SET status = 'ditolak', diproses_oleh = ?, diproses_at = NOW() WHERE id = ?`,
        [admin.id, id]
      );
      return NextResponse.json({ status: 'sukses', pesan: 'Penarikan ditolak, saldo dikembalikan' });
    }

    await execute(
      `UPDATE penarikan_request SET status = 'berhasil', diproses_oleh = ?, diproses_at = NOW() WHERE id = ?`,
      [admin.id, id]
    );
    try {
      await execute(`UPDATE users SET total_penarikan = COALESCE(total_penarikan,0) + ? WHERE id = ?`, [
        Number(p.nominal),
        p.user_id,
      ]);
    } catch {
      /* */
    }
    return NextResponse.json({ status: 'sukses', pesan: 'Penarikan ditandai berhasil' });
  } catch (e) {
    return NextResponse.json({ status: 'error', pesan: e instanceof Error ? e.message : 'Error' }, { status: 500 });
  }
}
