import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { jwtVerify } from 'jose';
import { execute, query, withTransaction, RowDataPacket } from '@/lib/db';

export const runtime = 'nodejs';

async function requireAdmin() {
  const jar = await cookies();
  const t = jar.get('v7_admin_token')?.value;
  if (!t || !process.env.JWT_SECRET) throw new Error('Unauthorized');
  const { payload } = await jwtVerify(t, new TextEncoder().encode(process.env.JWT_SECRET));
  return { id: Number(payload.id), username: String(payload.username) };
}

export async function GET(req: NextRequest) {
  try {
    await requireAdmin();
    const sp = req.nextUrl.searchParams;
    const dari = sp.get('dari') || '';
    const sampai = sp.get('sampai') || '';
    const status = sp.get('status') || '';

    let sql = `SELECT t.*, u.username, u.email, u.no_hp
       FROM topup_request t
       LEFT JOIN users u ON u.id = t.user_id
       WHERE 1=1`;
    const params: (string | number)[] = [];
    if (dari) {
      sql += ` AND DATE(t.created_at) >= ?`;
      params.push(dari);
    }
    if (sampai) {
      sql += ` AND DATE(t.created_at) <= ?`;
      params.push(sampai);
    }
    if (status) {
      sql += ` AND t.status = ?`;
      params.push(status);
    }
    sql += ` ORDER BY t.id DESC LIMIT 300`;

    const rows = await query<RowDataPacket[]>(sql, params);
    return NextResponse.json({ status: 'sukses', data: rows });
  } catch (e) {
    return NextResponse.json({ status: 'error', pesan: e instanceof Error ? e.message : 'Error' }, { status: 401 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const admin = await requireAdmin();
    const body = await req.json();
    const aksi = String(body.aksi || '');

    if (aksi === 'bulk' && Array.isArray(body.ids)) {
      let n = 0;
      for (const id of body.ids.map(Number).filter(Boolean)) {
        try {
          await withTransaction(async (conn) => {
            const [rows] = await conn.execute<RowDataPacket[]>(
              `SELECT * FROM topup_request WHERE id = ? AND status = 'menunggu' FOR UPDATE`,
              [id]
            );
            const t = rows[0];
            if (!t) return;
            if (body.status_aksi === 'tolak') {
              await conn.execute(
                `UPDATE topup_request SET status = 'ditolak', dikonfirmasi_oleh = ?, dikonfirmasi_at = NOW() WHERE id = ?`,
                [admin.id, id]
              );
            } else {
              await conn.execute(`UPDATE users SET saldo_deposit = COALESCE(saldo_deposit,0) + ? WHERE id = ?`, [
                Number(t.nominal),
                t.user_id,
              ]);
              await conn.execute(
                `UPDATE topup_request SET status = 'dikonfirmasi', dikonfirmasi_oleh = ?, dikonfirmasi_at = NOW() WHERE id = ?`,
                [admin.id, id]
              );
            }
            n++;
          });
        } catch {
          /* skip */
        }
      }
      return NextResponse.json({ status: 'sukses', pesan: `${n} topup diproses` });
    }

    const id = Number(body.id || 0);
    if (!id || !['konfirmasi', 'tolak'].includes(aksi)) {
      return NextResponse.json({ status: 'error', pesan: 'Data tidak valid' });
    }

    if (aksi === 'tolak') {
      await execute(
        `UPDATE topup_request SET status = 'ditolak', dikonfirmasi_oleh = ?, dikonfirmasi_at = NOW() WHERE id = ? AND status = 'menunggu'`,
        [admin.id, id]
      );
      return NextResponse.json({ status: 'sukses', pesan: 'Topup ditolak' });
    }

    await withTransaction(async (conn) => {
      const [rows] = await conn.execute<RowDataPacket[]>(
        `SELECT * FROM topup_request WHERE id = ? AND status = 'menunggu' FOR UPDATE`,
        [id]
      );
      const t = rows[0];
      if (!t) throw new Error('Request tidak ditemukan / sudah diproses');
      await conn.execute(`UPDATE users SET saldo_deposit = COALESCE(saldo_deposit,0) + ? WHERE id = ?`, [
        Number(t.nominal),
        t.user_id,
      ]);
      await conn.execute(
        `UPDATE topup_request SET status = 'dikonfirmasi', dikonfirmasi_oleh = ?, dikonfirmasi_at = NOW() WHERE id = ?`,
        [admin.id, id]
      );
    });

    return NextResponse.json({ status: 'sukses', pesan: 'Topup dikonfirmasi, saldo ditambahkan' });
  } catch (e) {
    return NextResponse.json({ status: 'error', pesan: e instanceof Error ? e.message : 'Error' }, { status: 500 });
  }
}
