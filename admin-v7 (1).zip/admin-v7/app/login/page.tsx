'use client';

import { useState, FormEvent } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [pesan, setPesan] = useState('');
  const [status, setStatus] = useState<'idle' | 'error' | 'sukses'>('idle');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setPesan('');
    setStatus('idle');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (data.status === 'sukses') {
        setStatus('sukses');
        setPesan(data.pesan || 'Login berhasil');
        router.push('/dashboard');
        router.refresh();
        return;
      }
      setStatus('error');
      setPesan(data.pesan || 'Login gagal');
    } catch {
      setStatus('error');
      setPesan('Gagal memanggil server');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 24,
      }}
    >
      <div className="card" style={{ width: 380, maxWidth: '100%' }}>
        <div style={{ textAlign: 'center', marginBottom: 22 }}>
          <h2 style={{ fontSize: 22 }}>Admin Panel</h2>
          <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>
            V7 System — khusus staff internal
          </p>
        </div>

        {status !== 'idle' && (
          <div className={`alert ${status === 'sukses' ? 'sukses' : 'error'}`}>{pesan}</div>
        )}

        <form onSubmit={onSubmit}>
          <div style={{ marginBottom: 16 }}>
            <label className="label">Username Admin</label>
            <input
              className="input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              autoComplete="username"
            />
          </div>
          <div style={{ marginBottom: 16 }}>
            <label className="label">Password</label>
            <input
              className="input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
            />
          </div>
          <button className="btn btn-primary" style={{ width: '100%' }} disabled={loading}>
            {loading ? 'Memproses…' : 'Masuk'}
          </button>
        </form>
      </div>
    </div>
  );
}
