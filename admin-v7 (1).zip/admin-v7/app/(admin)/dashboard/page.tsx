import { query, RowDataPacket } from '@/lib/db';

async function getStats() {
  const [users] = await query<RowDataPacket[]>('SELECT COUNT(*) AS c FROM users');
  const [produk] = await query<RowDataPacket[]>(
    "SELECT COUNT(*) AS c FROM produk WHERE status = 'aktif'"
  );
  const [topup] = await query<RowDataPacket[]>(
    "SELECT COUNT(*) AS c FROM topup_request WHERE status = 'pending'"
  );
  const [tarik] = await query<RowDataPacket[]>(
    "SELECT COUNT(*) AS c FROM penarikan_request WHERE status = 'pending'"
  );
  const [saldo] = await query<RowDataPacket[]>(
    'SELECT COALESCE(SUM(dompet_saldo),0) AS s FROM users'
  );
  return {
    users: Number(users?.c || 0),
    produkAktif: Number(produk?.c || 0),
    topupPending: Number(topup?.c || 0),
    tarikPending: Number(tarik?.c || 0),
    totalDompet: Number(saldo?.s || 0),
  };
}

export default async function DashboardPage() {
  let stats = {
    users: 0,
    produkAktif: 0,
    topupPending: 0,
    tarikPending: 0,
    totalDompet: 0,
  };
  let error = '';
  try {
    stats = await getStats();
  } catch (e) {
    error = e instanceof Error ? e.message : 'Gagal load statistik';
  }

  const cards = [
    { label: 'Total User', value: stats.users.toLocaleString('id-ID') },
    { label: 'Produk Aktif', value: stats.produkAktif.toLocaleString('id-ID') },
    { label: 'Topup Pending', value: stats.topupPending.toLocaleString('id-ID') },
    { label: 'Penarikan Pending', value: stats.tarikPending.toLocaleString('id-ID') },
    {
      label: 'Total Dompet User',
      value: 'Rp ' + stats.totalDompet.toLocaleString('id-ID'),
    },
  ];

  return (
    <div>
      <h1 className="page-title">Dashboard</h1>
      {error && <div className="alert error">{error}</div>}
      <div className="stat-grid">
        {cards.map((c) => (
          <div key={c.label} className="stat-card">
            <div className="label">{c.label}</div>
            <div className="value">{c.value}</div>
          </div>
        ))}
      </div>
      <div className="card">
        <p style={{ color: 'var(--muted)', fontSize: 13 }}>
          Admin V7 (Next.js) terhubung ke <strong style={{ color: '#fff' }}>Aiven MySQL</strong>{' '}
          + <strong style={{ color: '#fff' }}>Supabase Storage</strong>. Login & operasi kritis
          memakai connection pool terbatas agar Aiven trial tidak overload.
        </p>
      </div>
    </div>
  );
}
