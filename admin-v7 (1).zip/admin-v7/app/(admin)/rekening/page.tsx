'use client';
import { useEffect, useState } from 'react';

type Tab = 'mode' | 'topup' | 'penarikan' | 'gateway' | 'aktif';

export default function RekeningAdmin() {
  const [tab, setTab] = useState<Tab>('mode');
  const [topup, setTopup] = useState<any[]>([]);
  const [penarikan, setPenarikan] = useState<any[]>([]);
  const [apiList, setApiList] = useState<any[]>([]);
  const [modeTopup, setModeTopup] = useState('manual');
  const [modePenarikan, setModePenarikan] = useState('manual');
  const [gw, setGw] = useState<any>({ provider: '', mode: 'production', auto_webhook: '1' });
  const [msg, setMsg] = useState('');
  const [formTopup, setFormTopup] = useState({
    tipe: 'transfer', bank_nama: '', no_rekening: '', atas_nama: '', network: '', coin: 'USDT', urutan: 0, auto_konfirmasi: false,
  });
  const [formTarik, setFormTarik] = useState({ tipe: 'bank', nama: '', kode: '', urutan: 0, network: '', coin: '' });
  const [formApi, setFormApi] = useState({
    id: 0, nama: '', provider: 'midtrans', api_key: '', api_secret: '', merchant_id: '',
    webhook_url: '', mode: 'production', aktif: 1, catatan: '',
  });

  async function load() {
    const d = await (await fetch('/api/modules?mod=rekening')).json();
    if (d.status === 'sukses') {
      setTopup(d.topup || []);
      setPenarikan(d.penarikan || []);
      if (d.mode_topup) setModeTopup(d.mode_topup);
      if (d.mode_penarikan) setModePenarikan(d.mode_penarikan);
      if (d.gateway) setGw((g: any) => ({ ...g, ...d.gateway }));
    }
    const a = await (await fetch('/api/modules?mod=api_list')).json();
    if (a.status === 'sukses') setApiList(a.data || []);
  }
  useEffect(() => {
    load().catch(() => {});
  }, []);

  async function post(body: any) {
    const d = await (
      await fetch('/api/modules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })
    ).json();
    setMsg(d.pesan || d.status);
    load();
  }

  const tabs: { id: Tab; label: string }[] = [
    { id: 'mode', label: 'Mode & Gateway' },
    { id: 'topup', label: 'Metode Top Up' },
    { id: 'penarikan', label: 'Metode Penarikan' },
    { id: 'gateway', label: 'API Gateway' },
    { id: 'aktif', label: 'Daftar API & Aktif' },
  ];

  return (
    <div style={{ padding: 20 }}>
      <h1 style={{ marginBottom: 4 }}>Kelola Pembayaran</h1>
      <p style={{ color: '#888', fontSize: 13, marginBottom: 16 }}>Pilih menu di bawah — hanya satu bagian yang ditampilkan</p>
      {msg && <p style={{ color: '#facc15', marginBottom: 10 }}>{msg}</p>}

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            style={{
              ...tabBtn,
              borderColor: tab === t.id ? '#facc15' : '#333',
              color: tab === t.id ? '#facc15' : '#ccc',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'mode' && (
        <div style={card}>
          <h3 style={{ marginBottom: 8 }}>Mode Konfirmasi</h3>
          <p style={{ fontSize: 12, color: '#888', marginBottom: 12 }}>
            Manual = admin konfirmasi. Otomatis = webhook / payment gateway
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label style={label}>Mode Top Up</label>
              <select style={inp} value={modeTopup} onChange={(e) => setModeTopup(e.target.value)}>
                <option value="manual">Manual (admin konfirmasi)</option>
                <option value="otomatis">Otomatis (webhook / gateway)</option>
              </select>
            </div>
            <div>
              <label style={label}>Mode Penarikan</label>
              <select style={inp} value={modePenarikan} onChange={(e) => setModePenarikan(e.target.value)}>
                <option value="manual">Manual (admin proses)</option>
                <option value="otomatis">Otomatis (payout gateway)</option>
              </select>
            </div>
          </div>
          <button
            style={{ ...btn, marginTop: 14 }}
            type="button"
            onClick={() => post({ mod: 'rekening', aksi: 'simpan_mode', mode_topup: modeTopup, mode_penarikan: modePenarikan })}
          >
            Simpan Pengaturan
          </button>
        </div>
      )}

      {tab === 'topup' && (
        <div style={card}>
          <h3 style={{ marginBottom: 12 }}>Tambah Metode Top Up</h3>
          <label style={label}>Tipe</label>
          <select style={inp} value={formTopup.tipe} onChange={(e) => setFormTopup({ ...formTopup, tipe: e.target.value })}>
            <option value="transfer">Transfer Bank</option>
            <option value="qris">QRIS</option>
            <option value="ewallet">E-Wallet (DANA/OVO/GoPay)</option>
            <option value="gateway">Payment Gateway</option>
          </select>
          <label style={{ ...label, marginTop: 10 }}>Nama Bank / Layanan</label>
          <input style={inp} value={formTopup.bank_nama} onChange={(e) => setFormTopup({ ...formTopup, bank_nama: e.target.value })} />
          <label style={{ ...label, marginTop: 10 }}>No. Rekening / No. HP / Merchant ID</label>
          <input style={inp} value={formTopup.no_rekening} onChange={(e) => setFormTopup({ ...formTopup, no_rekening: e.target.value })} />
          <label style={{ ...label, marginTop: 10 }}>Atas Nama</label>
          <input style={inp} value={formTopup.atas_nama} onChange={(e) => setFormTopup({ ...formTopup, atas_nama: e.target.value })} />
          <label style={{ display: 'flex', gap: 8, alignItems: 'center', margin: '12px 0' }}>
            <input type="checkbox" checked={formTopup.auto_konfirmasi} onChange={(e) => setFormTopup({ ...formTopup, auto_konfirmasi: e.target.checked })} />
            Tandai siap auto-konfirmasi
          </label>
          
          <div>
            <label style={label}>Network (crypto)</label>
            <select style={inp} value={formTopup.network || ''} onChange={(e) => setFormTopup({ ...formTopup, network: e.target.value })}>
              <option value="">—</option>
              <option value="TRC20">TRC20</option>
              <option value="ERC20">ERC20</option>
              <option value="BEP20">BEP20</option>
              <option value="POLYGON">POLYGON</option>
              <option value="SOL">SOL</option>
            </select>
          </div>
          <div>
            <label style={label}>Coin</label>
            <select style={inp} value={formTopup.coin || 'USDT'} onChange={(e) => setFormTopup({ ...formTopup, coin: e.target.value })}>
              <option value="USDT">USDT</option>
              <option value="USDC">USDC</option>
              <option value="BTC">BTC</option>
              <option value="ETH">ETH</option>
              <option value="BNB">BNB</option>
              <option value="TRX">TRX</option>
            </select>
          </div>
          <p style={{ fontSize: 11, color: '#888', gridColumn: '1 / -1' }}>
            Untuk crypto: isi <b>No. Rekening</b> = alamat wallet, Bank = nama coin/jaringan (contoh USDT TRC20).
          </p>
<button style={btn} type="button" onClick={() => post({ mod: 'rekening', aksi: 'simpan_topup', ...formTopup })}>
            Simpan Metode Top Up
          </button>
        </div>
      )}

      {tab === 'penarikan' && (
        <div style={card}>
          <h3 style={{ marginBottom: 12 }}>Tambah Metode Penarikan</h3>
          <label style={label}>Tipe</label>
          <select style={inp} value={formTarik.tipe} onChange={(e) => setFormTarik({ ...formTarik, tipe: e.target.value })}>
            <option value="bank">Bank</option>
            <option value="ewallet">E-Wallet</option>
            <option value="crypto">Crypto (USDT/BTC/dll)</option>
          </select>
          <label style={{ ...label, marginTop: 10 }}>Nama</label>
          <input style={inp} value={formTarik.nama} onChange={(e) => setFormTarik({ ...formTarik, nama: e.target.value })} />
          <label style={{ ...label, marginTop: 10 }}>Kode</label>
          <input style={inp} value={formTarik.kode} onChange={(e) => setFormTarik({ ...formTarik, kode: e.target.value })} placeholder="bca / dana" />
          <button style={{ ...btn, marginTop: 12 }} type="button" onClick={() => post({ mod: 'rekening', aksi: 'simpan_penarikan', ...formTarik })}>
            Simpan Metode Penarikan
          </button>
        </div>
      )}

      {tab === 'gateway' && (
        <div style={card}>
          <h3 style={{ marginBottom: 12 }}>Parameter API Gateway (aktif tunggal)</h3>
          <label style={label}>Provider</label>
          <select style={inp} value={gw.provider || ''} onChange={(e) => setGw({ ...gw, provider: e.target.value })}>
            <option value="">— pilih —</option>
            <option value="casaku">Casaku</option>
            <option value="midtrans">Midtrans</option>
            <option value="xendit">Xendit</option>
            <option value="email_bank">Email Bank / Matcher</option>
          </select>
          <label style={{ ...label, marginTop: 10 }}>Mode</label>
          <select style={inp} value={gw.mode || 'production'} onChange={(e) => setGw({ ...gw, mode: e.target.value })}>
            <option value="sandbox">Sandbox</option>
            <option value="production">Production</option>
          </select>
          {(gw.provider === 'casaku') && (
            <>
              <label style={{ ...label, marginTop: 10 }}>License Key</label>
              <input style={inp} value={gw.license_key || ''} onChange={(e) => setGw({ ...gw, license_key: e.target.value })} />
              <label style={{ ...label, marginTop: 10 }}>Webhook Secret</label>
              <input style={inp} value={gw.webhook_secret || ''} onChange={(e) => setGw({ ...gw, webhook_secret: e.target.value })} />
              <label style={{ ...label, marginTop: 10 }}>QRIS ID</label>
              <input style={inp} value={gw.qris_id || ''} onChange={(e) => setGw({ ...gw, qris_id: e.target.value })} />
            </>
          )}
          {(gw.provider === 'midtrans' || gw.provider === 'xendit') && (
            <>
              <label style={{ ...label, marginTop: 10 }}>Server Key</label>
              <input style={inp} value={gw.server_key || ''} onChange={(e) => setGw({ ...gw, server_key: e.target.value })} />
              <label style={{ ...label, marginTop: 10 }}>Client Key</label>
              <input style={inp} value={gw.client_key || ''} onChange={(e) => setGw({ ...gw, client_key: e.target.value })} />
              <label style={{ ...label, marginTop: 10 }}>Merchant ID</label>
              <input style={inp} value={gw.merchant_id || ''} onChange={(e) => setGw({ ...gw, merchant_id: e.target.value })} />
            </>
          )}
          <label style={{ display: 'flex', gap: 8, alignItems: 'center', margin: '12px 0' }}>
            <input type="checkbox" checked={gw.auto_webhook !== '0'} onChange={(e) => setGw({ ...gw, auto_webhook: e.target.checked ? '1' : '0' })} />
            Aktifkan konfirmasi otomatis via webhook
          </label>
          <button style={btn} type="button" onClick={() => post({ mod: 'rekening', aksi: 'simpan_gateway', ...gw, auto_webhook: gw.auto_webhook !== '0' })}>
            Simpan Gateway
          </button>

          <hr style={{ border: 0, borderTop: '1px solid #333', margin: '24px 0' }} />
          <h3 style={{ marginBottom: 8 }}>🪙 Crypto Gateway</h3>
          <p style={{ fontSize: 12, color: '#888', marginBottom: 12 }}>
            NOWPayments / OxaPay / Binance Pay / manual wallet. Auto-konfirmasi jika IPN aktif.
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <label style={label}>Provider crypto</label>
              <select
                style={inp}
                value={gw.crypto_provider || ''}
                onChange={(e) => setGw({ ...gw, crypto_provider: e.target.value })}
              >
                <option value="">Manual (wallet sendiri)</option>
                <option value="nowpayments">NOWPayments</option>
                <option value="oxapay">OxaPay</option>
                <option value="binance_pay">Binance Pay</option>
                <option value="custom">Custom API</option>
              </select>
            </div>
            <div>
              <label style={label}>API Key / API Token</label>
              <input
                style={inp}
                value={gw.crypto_api_key || ''}
                onChange={(e) => setGw({ ...gw, crypto_api_key: e.target.value })}
                placeholder="API key provider"
              />
            </div>
            <div>
              <label style={label}>IPN / Webhook Secret</label>
              <input
                style={inp}
                value={gw.crypto_ipn_secret || ''}
                onChange={(e) => setGw({ ...gw, crypto_ipn_secret: e.target.value })}
              />
            </div>
            <div>
              <label style={label}>Coin default</label>
              <select
                style={inp}
                value={gw.crypto_default_coin || 'USDT'}
                onChange={(e) => setGw({ ...gw, crypto_default_coin: e.target.value })}
              >
                <option value="USDT">USDT</option>
                <option value="USDC">USDC</option>
                <option value="BTC">BTC</option>
                <option value="ETH">ETH</option>
                <option value="BNB">BNB</option>
                <option value="TRX">TRX</option>
              </select>
            </div>
            <div>
              <label style={label}>Network default</label>
              <select
                style={inp}
                value={gw.crypto_default_network || 'TRC20'}
                onChange={(e) => setGw({ ...gw, crypto_default_network: e.target.value })}
              >
                <option value="TRC20">TRC20 (Tron)</option>
                <option value="ERC20">ERC20 (Ethereum)</option>
                <option value="BEP20">BEP20 (BSC)</option>
                <option value="POLYGON">Polygon</option>
                <option value="SOL">Solana</option>
              </select>
            </div>
          </div>
          <label style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 10, fontSize: 13 }}>
            <input
              type="checkbox"
              checked={gw.crypto_auto_confirm === '1'}
              onChange={(e) => setGw({ ...gw, crypto_auto_confirm: e.target.checked ? '1' : '0' })}
            />
            Auto-konfirmasi top up/penarikan crypto setelah IPN gateway
          </label>
          <button
            style={{ ...btn, marginTop: 12 }}
            type="button"
            onClick={() =>
              post({
                mod: 'rekening',
                aksi: 'simpan_crypto_gateway',
                ...gw,
                crypto_auto_confirm: gw.crypto_auto_confirm === '1',
              })
            }
          >
            Simpan Crypto Gateway
          </button>
        </div>
      )}

      {tab === 'aktif' && (
        <div>
          {/* DAFTAR API */}
          <div style={{ ...card, marginBottom: 16 }}>
            <h3 style={{ marginBottom: 8 }}>Daftar API (lihat / edit / aktif-nonaktif)</h3>
            <p style={{ fontSize: 12, color: '#888', marginBottom: 12 }}>
              Simpan banyak konfigurasi API. Hanya yang berstatus AKTIF bisa dipilih sebagai gateway operasional.
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <div>
                <label style={label}>Nama tampilan</label>
                <input style={inp} value={formApi.nama} onChange={(e) => setFormApi({ ...formApi, nama: e.target.value })} placeholder="Midtrans Produksi" />
              </div>
              <div>
                <label style={label}>Provider</label>
                <select style={inp} value={formApi.provider} onChange={(e) => setFormApi({ ...formApi, provider: e.target.value })}>
                  <option value="midtrans">Midtrans</option>
                  <option value="xendit">Xendit</option>
                  <option value="casaku">Casaku</option>
                  <option value="ipaymu">iPaymu</option>
                  <option value="lainnya">Lainnya</option>
                </select>
              </div>
              <div>
                <label style={label}>API Key / Server Key</label>
                <input style={inp} value={formApi.api_key} onChange={(e) => setFormApi({ ...formApi, api_key: e.target.value })} />
              </div>
              <div>
                <label style={label}>API Secret / Client Key</label>
                <input style={inp} value={formApi.api_secret} onChange={(e) => setFormApi({ ...formApi, api_secret: e.target.value })} />
              </div>
              <div>
                <label style={label}>Merchant ID</label>
                <input style={inp} value={formApi.merchant_id} onChange={(e) => setFormApi({ ...formApi, merchant_id: e.target.value })} />
              </div>
              <div>
                <label style={label}>Mode</label>
                <select style={inp} value={formApi.mode} onChange={(e) => setFormApi({ ...formApi, mode: e.target.value })}>
                  <option value="sandbox">Sandbox</option>
                  <option value="production">Production</option>
                </select>
              </div>
            </div>
            <label style={{ ...label, marginTop: 10 }}>Webhook URL</label>
            <input style={inp} value={formApi.webhook_url} onChange={(e) => setFormApi({ ...formApi, webhook_url: e.target.value })} placeholder="https://..." />
            <label style={{ ...label, marginTop: 10 }}>Catatan</label>
            <input style={inp} value={formApi.catatan} onChange={(e) => setFormApi({ ...formApi, catatan: e.target.value })} />
            <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
              <button
                style={btn}
                type="button"
                onClick={() => {
                  post({ mod: 'api_list', aksi: 'simpan', ...formApi });
                  setFormApi({
                    id: 0, nama: '', provider: 'midtrans', api_key: '', api_secret: '', merchant_id: '',
                    webhook_url: '', mode: 'production', aktif: 1, catatan: '',
                  });
                }}
              >
                {formApi.id ? 'Update API' : 'Tambah API'}
              </button>
              {formApi.id > 0 && (
                <button
                  style={btnGhost}
                  type="button"
                  onClick={() =>
                    setFormApi({
                      id: 0, nama: '', provider: 'midtrans', api_key: '', api_secret: '', merchant_id: '',
                      webhook_url: '', mode: 'production', aktif: 1, catatan: '',
                    })
                  }
                >
                  Batal edit
                </button>
              )}
            </div>

            <div style={{ overflowX: 'auto', marginTop: 16 }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr style={{ color: '#aaa', textAlign: 'left' }}>
                    <th style={th}>NAMA</th>
                    <th style={th}>PROVIDER</th>
                    <th style={th}>MODE</th>
                    <th style={th}>STATUS</th>
                    <th style={th}>AKSI</th>
                  </tr>
                </thead>
                <tbody>
                  {apiList.length === 0 && (
                    <tr>
                      <td colSpan={5} style={{ ...td, color: '#888' }}>
                        Belum ada API tersimpan
                      </td>
                    </tr>
                  )}
                  {apiList.map((r) => (
                    <tr key={r.id} style={{ borderTop: '1px solid #222' }}>
                      <td style={td}>
                        <b>{r.nama}</b>
                        <div style={{ fontSize: 11, color: '#666' }}>{r.merchant_id || ''}</div>
                      </td>
                      <td style={td}>{r.provider}</td>
                      <td style={td}>{r.mode}</td>
                      <td style={td}>
                        <span style={{ color: r.aktif ? '#4ade80' : '#888' }}>{r.aktif ? 'AKTIF' : 'NONAKTIF'}</span>
                      </td>
                      <td style={td}>
                        <button
                          style={btnGhost}
                          type="button"
                          onClick={() =>
                            setFormApi({
                              id: r.id,
                              nama: r.nama || '',
                              provider: r.provider || 'midtrans',
                              api_key: r.api_key || '',
                              api_secret: r.api_secret || '',
                              merchant_id: r.merchant_id || '',
                              webhook_url: r.webhook_url || '',
                              mode: r.mode || 'production',
                              aktif: r.aktif ? 1 : 0,
                              catatan: r.catatan || '',
                            })
                          }
                        >
                          Edit
                        </button>{' '}
                        <button
                          style={btnGhost}
                          type="button"
                          onClick={() => post({ mod: 'api_list', aksi: 'toggle', id: r.id, aktif: !r.aktif })}
                        >
                          {r.aktif ? 'Nonaktifkan' : 'Aktifkan'}
                        </button>{' '}
                        <button style={btnRed} type="button" onClick={() => post({ mod: 'api_list', aksi: 'hapus', id: r.id })}>
                          Hapus
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Metode topup aktif */}
          <div style={{ ...card, marginBottom: 16 }}>
            <h3 style={{ marginBottom: 10 }}>Metode Top Up aktif</h3>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr style={{ color: '#aaa', textAlign: 'left' }}>
                  <th style={th}>TIPE</th>
                  <th style={th}>BANK/LAYANAN</th>
                  <th style={th}>NO</th>
                  <th style={th}>ATAS NAMA</th>
                  <th style={th}>AKSI</th>
                </tr>
              </thead>
              <tbody>
                {topup.map((r) => (
                  <tr key={r.id} style={{ borderTop: '1px solid #222' }}>
                    <td style={td}>
                      <span style={badge}>{String(r.tipe).toUpperCase()}</span>
                    </td>
                    <td style={td}>{r.bank_nama}</td>
                    <td style={td}>{r.no_rekening}</td>
                    <td style={td}>{r.atas_nama}</td>
                    <td style={td}>
                      <button style={btnRed} type="button" onClick={() => post({ mod: 'rekening', aksi: 'hapus_topup', id: r.id })}>
                        Hapus
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={card}>
            <h3 style={{ marginBottom: 10 }}>Metode Penarikan aktif</h3>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr style={{ color: '#aaa', textAlign: 'left' }}>
                  <th style={th}>TIPE</th>
                  <th style={th}>NAMA</th>
                  <th style={th}>KODE</th>
                  <th style={th}>STATUS</th>
                  <th style={th}>AKSI</th>
                </tr>
              </thead>
              <tbody>
                {penarikan.map((r) => (
                  <tr key={r.id} style={{ borderTop: '1px solid #222' }}>
                    <td style={td}>
                      <span style={badge}>{String(r.tipe).toUpperCase()}</span>
                    </td>
                    <td style={td}>
                      <b>{r.nama}</b>
                    </td>
                    <td style={td}>{r.kode}</td>
                    <td style={td}>
                      <span style={{ color: r.aktif ? '#4ade80' : '#888' }}>{r.aktif ? 'AKTIF' : 'OFF'}</span>
                    </td>
                    <td style={td}>
                      <button
                        style={btnGhost}
                        type="button"
                        onClick={() => post({ mod: 'rekening', aksi: 'toggle_penarikan', id: r.id, aktif: !r.aktif })}
                      >
                        {r.aktif ? 'Nonaktifkan' : 'Aktifkan'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

const card: React.CSSProperties = { background: 'rgba(255,255,255,0.04)', border: '1px solid #222', borderRadius: 14, padding: 16 };
const label: React.CSSProperties = { display: 'block', fontSize: 12, color: '#aaa', marginBottom: 6 };
const inp: React.CSSProperties = { width: '100%', padding: 10, borderRadius: 8, border: '1px solid #333', background: '#111', color: '#fff' };
const btn: React.CSSProperties = { background: '#facc15', border: 0, padding: '10px 16px', borderRadius: 8, fontWeight: 700, cursor: 'pointer', color: '#000' };
const btnGhost: React.CSSProperties = { background: 'transparent', border: '1px solid #555', color: '#fff', padding: '4px 10px', borderRadius: 8, cursor: 'pointer', fontSize: 12 };
const btnRed: React.CSSProperties = { background: '#dc3545', border: 0, color: '#fff', padding: '4px 10px', borderRadius: 8, cursor: 'pointer', fontSize: 12 };
const tabBtn: React.CSSProperties = { background: 'rgba(255,255,255,0.03)', border: '1px solid #333', borderRadius: 12, padding: '12px 14px', cursor: 'pointer', fontSize: 13 };
const th: React.CSSProperties = { padding: '8px 6px' };
const td: React.CSSProperties = { padding: '10px 6px' };
const badge: React.CSSProperties = { display: 'inline-block', padding: '2px 8px', borderRadius: 6, background: 'rgba(56,189,248,0.15)', color: '#38bdf8', fontSize: 11, fontWeight: 600 };
