'use client';
import { useEffect, useState } from 'react';

export default function KomunitasAdminPage() {
  const [isi, setIsi] = useState('');
  const [mediaType, setMediaType] = useState<'none' | 'gambar' | 'video'>('none');
  const [file, setFile] = useState<File | null>(null);
  const [list, setList] = useState<any[]>([]);
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  async function load() {
    const d = await (await fetch('/api/modules?mod=komunitas')).json();
    if (d.status === 'sukses') setList(d.data || []);
  }
  useEffect(() => {
    load().catch(() => {});
  }, []);

  async function posting() {
    if (!isi.trim() && !file) {
      setMsg('Isi teks atau pilih file media');
      return;
    }
    setLoading(true);
    setMsg('');
    try {
      const fd = new FormData();
      fd.set('mod', 'komunitas');
      fd.set('aksi', 'posting');
      fd.set('isi', isi);
      fd.set('media_type', mediaType === 'none' ? '' : mediaType);
      if (file) fd.set('file', file);

      const d = await (await fetch('/api/modules', { method: 'POST', body: fd })).json();
      setMsg(d.pesan || d.status);
      if (d.status === 'sukses') {
        setIsi('');
        setFile(null);
        setMediaType('none');
        load();
      }
    } catch {
      setMsg('Gagal posting');
    }
    setLoading(false);
  }

  async function hapus(id: number) {
    if (!confirm('Hapus postingan?')) return;
    const d = await (
      await fetch('/api/modules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mod: 'komunitas', aksi: 'hapus', id }),
      })
    ).json();
    setMsg(d.pesan || '');
    load();
  }

  return (
    <div>
      <h1 className="page-title">Komunitas</h1>
      <p style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 14 }}>
        Hanya admin & sub-admin (izin komunitas) yang dapat menulis. Member hanya membaca.
        Upload <b>gambar/video langsung</b> dari komputer (disimpan ke Supabase), bukan hanya URL.
      </p>
      {msg && <div className="alert" style={{ marginBottom: 12 }}>{msg}</div>}

      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 10 }}>Buat Postingan</h3>
        <textarea
          className="input"
          rows={4}
          placeholder="Tulis pengumuman untuk member..."
          value={isi}
          onChange={(e) => setIsi(e.target.value)}
          style={{ width: '100%', marginBottom: 10 }}
        />
        <label className="label">Jenis media</label>
        <select
          className="input"
          value={mediaType}
          onChange={(e) => {
            setMediaType(e.target.value as any);
            setFile(null);
          }}
          style={{ width: '100%', marginBottom: 10 }}
        >
          <option value="none">Tanpa media</option>
          <option value="gambar">Gambar (upload file)</option>
          <option value="video">Video (upload file)</option>
        </select>
        {mediaType !== 'none' && (
          <>
            <label className="label">Pilih file dari perangkat</label>
            <input
              className="input"
              type="file"
              accept={mediaType === 'gambar' ? 'image/jpeg,image/png,image/webp,image/gif' : 'video/mp4,video/webm,video/quicktime'}
              onChange={(e) => setFile(e.target.files?.[0] || null)}
              style={{ width: '100%', marginBottom: 8 }}
            />
            {file && (
              <p style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 8 }}>
                File: {file.name} ({Math.round(file.size / 1024)} KB)
              </p>
            )}
          </>
        )}
        <button className="btn btn-primary" type="button" disabled={loading} onClick={posting}>
          {loading ? 'Mengunggah…' : 'Posting'}
        </button>
      </div>

      <div className="card">
        <h3 style={{ marginBottom: 10 }}>Postingan ({list.length})</h3>
        {list.length === 0 && <p style={{ color: 'var(--muted)' }}>Belum ada postingan</p>}
        {list.map((p: any) => (
          <div key={p.id} style={{ borderBottom: '1px solid #222', padding: '12px 0' }}>
            <div style={{ whiteSpace: 'pre-wrap', fontSize: 14 }}>{p.isi}</div>
            {p.media_url && p.media_type === 'gambar' && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={p.media_url} alt="" style={{ maxWidth: '100%', maxHeight: 320, marginTop: 8, borderRadius: 8 }} />
            )}
            {p.media_url && p.media_type === 'video' && (
              <video src={p.media_url} controls style={{ maxWidth: '100%', marginTop: 8, borderRadius: 8 }} />
            )}
            <button type="button" className="btn btn-ghost" style={{ marginTop: 8, fontSize: 12 }} onClick={() => hapus(p.id)}>
              Hapus
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
