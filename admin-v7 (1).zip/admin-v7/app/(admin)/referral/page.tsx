'use client';
import { useEffect, useState } from 'react';

export default function ReferralPage() {
  const [levels, setLevels] = useState<{ level: number; persen: number }[]>([
    { level: 1, persen: 10 },
    { level: 2, persen: 5 },
    { level: 3, persen: 2 },
  ]);
  const [khusus, setKhusus] = useState<any[]>([]);
  const [stats, setStats] = useState({ member_upline: 0, total_komisi: 0 });
  const [userKey, setUserKey] = useState('');
  const [khususPersen, setKhususPersen] = useState<number[]>([10, 5, 3]);
  const [msg, setMsg] = useState('');

  async function load() {
    const d = await (await fetch('/api/modules?mod=referral')).json();
    if (d.status === 'sukses') {
      if (d.levels?.length) setLevels(d.levels.map((r: any) => ({ level: Number(r.level), persen: Number(r.persen) })));
      setKhusus(d.khusus || []);
      setStats({
        member_upline: Number(d.stats?.member_upline || 0),
        total_komisi: Number(d.stats?.total_komisi || 0),
      });
    }
  }
  useEffect(() => {
    load().catch(() => {});
  }, []);

  function addLevel() {
    const next = levels.length ? Math.max(...levels.map((l) => l.level)) + 1 : 1;
    setLevels((p) => [...p, { level: next, persen: 0 }]);
  }

  async function simpanLevels() {
    const d = await (
      await fetch('/api/modules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mod: 'referral', aksi: 'simpan_levels', levels }),
      })
    ).json();
    setMsg(d.pesan || d.status);
    load();
  }

  async function simpanKhusus() {
    const d = await (
      await fetch('/api/modules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mod: 'referral',
          aksi: 'simpan_khusus',
          user_key: userKey,
          persen: khususPersen,
        }),
      })
    ).json();
    setMsg(d.pesan || d.status);
    if (d.status === 'sukses') {
      setUserKey('');
      load();
    }
  }

  return (
    <div>
      <h1 className="page-title">Kelola Referral</h1>
      <p style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 14 }}>Persentase komisi per tingkat referral</p>
      {msg && <div className="alert" style={{ marginBottom: 12 }}>{msg}</div>}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
        <div className="card">
          <div style={{ fontSize: 12, color: 'var(--muted)' }}>Member Punya Upline</div>
          <div style={{ fontSize: 28, fontWeight: 800 }}>{stats.member_upline}</div>
        </div>
        <div className="card">
          <div style={{ fontSize: 12, color: 'var(--muted)' }}>Total Komisi (semua user)</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: 'var(--primary)' }}>
            Rp {stats.total_komisi.toLocaleString('id-ID')}
          </div>
        </div>
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 12 }}>Persen default per level</h3>
        {levels.map((l, i) => (
          <div key={l.level} style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 8 }}>
            <span style={{ width: 80 }}>Level {l.level}</span>
            <input
              className="input"
              type="number"
              value={l.persen}
              onChange={(e) =>
                setLevels((prev) => prev.map((x, idx) => (idx === i ? { ...x, persen: Number(e.target.value) } : x)))
              }
              style={{ width: 100 }}
            />
            <span>%</span>
          </div>
        ))}
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          <button type="button" className="btn" onClick={addLevel}>+ Tambah Level</button>
          <button type="button" className="btn btn-primary" onClick={simpanLevels}>Simpan</button>
        </div>
      </div>

      <div className="card">
        <h3 style={{ marginBottom: 12 }}>Referral Khusus (per client, banyak akun)</h3>
        <p style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 10 }}>
          Bisa set lebih dari 3 tingkat. Isi persen berurutan level 1, 2, 3, …
        </p>
        <input
          className="input"
          placeholder="username atau id_user"
          value={userKey}
          onChange={(e) => setUserKey(e.target.value)}
          style={{ width: '100%', marginBottom: 8 }}
        />
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 10 }}>
          {khususPersen.map((p, i) => (
            <input
              key={i}
              className="input"
              type="number"
              style={{ width: 80 }}
              value={p}
              onChange={(e) => {
                const n = [...khususPersen];
                n[i] = Number(e.target.value);
                setKhususPersen(n);
              }}
              title={`Level ${i + 1}`}
            />
          ))}
          <button type="button" className="btn" onClick={() => setKhususPersen((p) => [...p, 0])}>
            + Level
          </button>
        </div>
        <button type="button" className="btn btn-primary" onClick={simpanKhusus}>
          Simpan Khusus
        </button>
        <div style={{ marginTop: 16 }}>
          {khusus.length === 0 && <p style={{ color: 'var(--muted)' }}>Belum ada pengaturan khusus</p>}
          {khusus.map((k: any) => (
            <div key={k.id} style={{ fontSize: 13, padding: '8px 0', borderBottom: '1px solid #222' }}>
              {k.username || k.user_id} — {JSON.stringify(k.persen || k)}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
