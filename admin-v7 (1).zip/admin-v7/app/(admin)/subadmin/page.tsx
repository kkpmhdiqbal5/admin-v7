'use client';
import { useEffect, useState } from 'react';

const OTORITAS = [
  { key: 'produk', label: 'Kelola / Buat Produk' },
  { key: 'akun', label: 'Kelola Akun' },
  { key: 'chat', label: 'Live Chat' },
  { key: 'redeem', label: 'Kode Redeem' },
  { key: 'referral', label: 'Referral' },
  { key: 'vip', label: 'Tingkat VIP' },
  { key: 'komunitas', label: 'Komunitas' },
  { key: 'topup', label: 'Top Up / Penarikan / Rekening' },
  { key: 'tampilan', label: 'Tampilan Client' },
  { key: 'checkin', label: 'Check-in Harian' },
  { key: 'fonnte', label: 'API OTP Fonnte' },
];

type Row = { id: number; username: string; role: string; izin: string; status: string };

export default function SubAdminPage() {
  const [list, setList] = useState<Row[]>([]);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [izin, setIzin] = useState<string[]>([]);
  const [msg, setMsg] = useState('');

  async function load() {
    const d = await (await fetch('/api/modules?mod=subadmin')).json();
    if (d.status === 'sukses') setList(d.data || []);
  }
  useEffect(() => {
    load().catch(() => {});
  }, []);

  function toggle(k: string) {
    setIzin((prev) => (prev.includes(k) ? prev.filter((x) => x !== k) : [...prev, k]));
  }

  async function buat() {
    setMsg('');
    const d = await (
      await fetch('/api/modules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mod: 'subadmin', aksi: 'buat', username, password, izin }),
      })
    ).json();
    setMsg(d.pesan || d.status);
    if (d.status === 'sukses') {
      setUsername('');
      setPassword('');
      setIzin([]);
      load();
    }
  }

  return (
    <div>
      <h1 className="page-title">Sub-Admin</h1>
      <p style={{ color: 'var(--muted)', marginBottom: 16, fontSize: 13 }}>
        Buat akun staff dan atur otoritas per menu. Sub-admin tidak bisa membuat sub-admin lain.
      </p>
      {msg && <div className="alert" style={{ marginBottom: 12 }}>{msg}</div>}

      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 12 }}>Tambah Sub-Admin</h3>
        <label className="label">Username</label>
        <input className="input" value={username} onChange={(e) => setUsername(e.target.value)} style={{ width: '100%', marginBottom: 10 }} />
        <label className="label">Password</label>
        <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} style={{ width: '100%', marginBottom: 12 }} />
        <div style={{ fontSize: 13, marginBottom: 8 }}>Otoritas (centang menu yang boleh diakses)</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 14 }}>
          {OTORITAS.map((o) => (
            <label key={o.key} style={{ display: 'flex', gap: 8, alignItems: 'center', fontSize: 13 }}>
              <input type="checkbox" checked={izin.includes(o.key)} onChange={() => toggle(o.key)} />
              {o.label}
            </label>
          ))}
        </div>
        <button className="btn btn-primary" type="button" onClick={buat}>
          Buat Sub-Admin
        </button>
      </div>

      <div className="card">
        <h3 style={{ marginBottom: 12 }}>Daftar Sub-Admin</h3>
        {list.filter((r) => r.role !== 'admin' && r.role !== 'super_admin').length === 0 && (
          <p style={{ color: 'var(--muted)' }}>Belum ada sub-admin.</p>
        )}
        {list
          .filter((r) => r.role !== 'admin' && r.role !== 'super_admin')
          .map((r) => (
            <div key={r.id} style={{ borderBottom: '1px solid #222', padding: '10px 0', fontSize: 13 }}>
              <b>{r.username}</b> · {r.status}
              <div style={{ color: 'var(--muted)', marginTop: 4 }}>Izin: {r.izin || '—'}</div>
            </div>
          ))}
      </div>
    </div>
  );
}
