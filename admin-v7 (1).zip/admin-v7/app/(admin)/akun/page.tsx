'use client';
import { useEffect, useState } from 'react';

export default function AkunAdmin() {
  const [rows, setRows] = useState<any[]>([]);
  const [msg, setMsg] = useState('');

  async function load() {
    const d = await (await fetch('/api/modules?mod=akun')).json();
    if (d.status === 'sukses') setRows(d.data || []);
  }
  useEffect(() => { load(); }, []);

  async function simpan(id: number, vip_level: string, status_akun: string) {
    const d = await (await fetch('/api/modules', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mod: 'akun', aksi: 'simpan', id, vip_level, status_akun }),
    })).json();
    setMsg(d.pesan); load();
  }

  return (
    <div style={{ padding: 20 }}>
      <h1 style={{ marginBottom: 4 }}>Kelola Akun Client</h1>
      <p style={{ color: '#888', fontSize: 13, marginBottom: 16 }}>Hanya data non-finansial (VIP level & status akun). Saldo tidak bisa diubah langsung — gunakan menu Kode Redeem.</p>
      {msg && <p style={{ color: '#4ade80', marginBottom: 12 }}>{msg}</p>}
      <div style={{ ...card, overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ color: '#aaa', textAlign: 'left' }}>
              <th style={th}>ID</th><th style={th}>USERNAME</th><th style={th}>EMAIL</th><th style={th}>NO. HP</th><th style={th}>VIP</th><th style={th}>STATUS</th><th style={th}>AKSI</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <AkunRow key={r.id} r={r} onSave={simpan} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AkunRow({ r, onSave }: { r: any; onSave: (id: number, vip: string, status: string) => void }) {
  const [vip, setVip] = useState(r.vip_level || 'VIP1');
  const [status, setStatus] = useState(r.status_akun || 'aktif');
  return (
    <tr style={{ borderTop: '1px solid #222' }}>
      <td style={td}>{r.id_user || r.id}</td>
      <td style={td}>{r.username}</td>
      <td style={td}>{r.email || '—'}</td>
      <td style={td}>{r.no_hp || '—'}</td>
      <td style={td}>
        <select style={sel} value={vip} onChange={(e) => setVip(e.target.value)}>
          {['VIP1','VIP2','VIP3','VIP4','VIP5'].map((v) => <option key={v}>{v}</option>)}
        </select>
      </td>
      <td style={td}>
        <select style={sel} value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="aktif">Aktif</option>
          <option value="nonaktif">Nonaktif</option>
          <option value="banned">Banned</option>
        </select>
      </td>
      <td style={td}><button style={btn} onClick={() => onSave(r.id, vip, status)}>Simpan</button></td>
    </tr>
  );
}
const card: React.CSSProperties = { background: 'rgba(255,255,255,0.04)', border: '1px solid #222', borderRadius: 14, padding: 16 };
const th: React.CSSProperties = { padding: '8px 6px' };
const td: React.CSSProperties = { padding: '10px 6px' };
const sel: React.CSSProperties = { padding: 6, borderRadius: 6, border: '1px solid #333', background: '#111', color: '#fff' };
const btn: React.CSSProperties = { background: '#facc15', border: 0, padding: '6px 12px', borderRadius: 8, fontWeight: 700, cursor: 'pointer', color: '#000' };
