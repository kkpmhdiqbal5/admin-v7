'use client';
import { useEffect, useRef, useState } from 'react';

type Thread = {
  user_id: number;
  username: string;
  last_pesan?: string;
  last_at?: string;
  unread?: number;
  chat_verifikasi?: string;
};
type Msg = {
  id: number;
  pengirim: string;
  pesan: string;
  media_url?: string;
  media_type?: string;
  created_at?: string;
};

export default function ChatAdminPage() {
  const [tab, setTab] = useState<'baru' | 'lama'>('baru');
  const [threads, setThreads] = useState<Thread[]>([]);
  const [active, setActive] = useState<number | null>(null);
  const [activeName, setActiveName] = useState('');
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [info, setInfo] = useState('');
  const bottom = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  async function loadInbox() {
    const d = await (await fetch(`/api/modules?mod=chat_inbox&tab=${tab}`)).json();
    if (d.status === 'sukses') setThreads(d.data || []);
  }

  async function loadThread(uid: number, name?: string) {
    setActive(uid);
    if (name) setActiveName(name);
    const d = await (await fetch(`/api/modules?mod=chat_thread&user_id=${uid}`)).json();
    if (d.status === 'sukses') setMsgs(d.data || []);
    loadInbox();
  }

  useEffect(() => {
    setActive(null);
    setMsgs([]);
    loadInbox().catch(() => {});
    const t = setInterval(() => loadInbox().catch(() => {}), 4000);
    return () => clearInterval(t);
  }, [tab]);

  useEffect(() => {
    if (!active) return;
    const t = setInterval(() => loadThread(active).catch(() => {}), 4000);
    return () => clearInterval(t);
  }, [active]);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: 'smooth' });
  }, [msgs]);

  async function kirim() {
    if (!active || (!text.trim() && !file)) return;
    setLoading(true);
    try {
      const fd = new FormData();
      fd.set('mod', 'chat');
      fd.set('aksi', 'balas');
      fd.set('user_id', String(active));
      fd.set('pesan', text);
      if (file) fd.set('file', file);
      await fetch('/api/modules', { method: 'POST', body: fd });
      setText('');
      setFile(null);
      if (fileRef.current) fileRef.current.value = '';
      await loadThread(active);
    } finally {
      setLoading(false);
    }
  }

  async function verifikasi(to: 'lama' | 'baru') {
    if (!active) return;
    setLoading(true);
    setInfo('');
    try {
      const d = await (
        await fetch('/api/modules', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mod: 'chat',
            aksi: to === 'lama' ? 'verifikasi' : 'batal_verifikasi',
            user_id: active,
          }),
        })
      ).json();
      setInfo(d.pesan || d.status);
      if (d.status === 'sukses') {
        setActive(null);
        setMsgs([]);
        loadInbox();
      }
    } finally {
      setLoading(false);
    }
  }

  const totalUnread = threads.reduce((s, t) => s + Number(t.unread || 0), 0);

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr', gap: 12, height: 'calc(100vh - 100px)' }}>
      <div className="card" style={{ overflow: 'auto', padding: 0, display: 'relative' }}>
        <div style={{ display: 'flex', gap: 0, borderBottom: '1px solid #222' }}>
          {(['baru', 'lama'] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              style={{
                flex: 1,
                padding: 12,
                border: 0,
                background: tab === t ? 'rgba(250,204,21,0.12)' : 'transparent',
                color: tab === t ? '#facc15' : '#888',
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              {t === 'baru' ? 'Client Baru' : 'Client Lama'}
              {t === tab && totalUnread > 0 && (
                <span
                  style={{
                    marginLeft: 6,
                    background: '#ef4444',
                    color: '#fff',
                    borderRadius: 10,
                    padding: '1px 7px',
                    fontSize: 11,
                  }}
                >
                  {totalUnread}
                </span>
              )}
            </button>
          ))}
        </div>
        {threads.map((t) => (
          <button
            key={t.user_id}
            type="button"
            onClick={() => loadThread(t.user_id, t.username)}
            style={{
              display: 'flex',
              width: '100%',
              textAlign: 'left',
              padding: '12px 14px',
              border: 0,
              borderBottom: '1px solid #1a1a1a',
              background: active === t.user_id ? 'rgba(250,204,21,0.08)' : 'transparent',
              color: '#fff',
              cursor: 'pointer',
              gap: 10,
              alignItems: 'center',
            }}
          >
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6 }}>
                {t.username || `User #${t.user_id}`}
                {Number(t.unread) > 0 && (
                  <span
                    style={{
                      background: '#ef4444',
                      color: '#fff',
                      borderRadius: 10,
                      padding: '1px 6px',
                      fontSize: 10,
                      fontWeight: 800,
                    }}
                  >
                    {t.unread}
                  </span>
                )}
              </div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {t.last_pesan || '—'}
              </div>
            </div>
          </button>
        ))}
        {threads.length === 0 && (
          <p style={{ color: '#666', padding: 16, fontSize: 13 }}>
            Belum ada chat di tab ini. Client yang mengirim pesan muncul di <b>Client Baru</b> sampai Anda verifikasi.
          </p>
        )}
      </div>

      <div className="card" style={{ display: 'flex', flexDirection: 'column', padding: 0 }}>
        {!active ? (
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#666', flexDirection: 'column', gap: 8 }}>
            <div>Pilih client di kiri</div>
            <div style={{ fontSize: 12, maxWidth: 320, textAlign: 'center' }}>
              Setelah membantu client baru, klik <b>Verifikasi Client</b> agar pindah ke tab Client Lama.
            </div>
          </div>
        ) : (
          <>
            <div
              style={{
                padding: '10px 14px',
                borderBottom: '1px solid #222',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 8,
              }}
            >
              <div style={{ fontWeight: 700 }}>{activeName || `User #${active}`}</div>
              <div style={{ display: 'flex', gap: 8 }}>
                {tab === 'baru' ? (
                  <button type="button" className="btn btn-primary" disabled={loading} onClick={() => verifikasi('lama')} style={{ fontSize: 12 }}>
                    ✓ Verifikasi → Client Lama
                  </button>
                ) : (
                  <button type="button" className="btn btn-ghost" disabled={loading} onClick={() => verifikasi('baru')} style={{ fontSize: 12 }}>
                    Kembalikan ke Baru
                  </button>
                )}
              </div>
            </div>
            {info && <div style={{ padding: '6px 14px', fontSize: 12, color: '#facc15' }}>{info}</div>}
            <div style={{ flex: 1, overflow: 'auto', padding: 14 }}>
              {msgs.map((m) => {
                const admin = m.pengirim === 'admin';
                return (
                  <div
                    key={m.id}
                    style={{
                      maxWidth: '75%',
                      marginBottom: 10,
                      marginLeft: admin ? 'auto' : 0,
                      background: admin ? 'rgba(250,204,21,0.15)' : '#1a1a1a',
                      padding: '8px 12px',
                      borderRadius: 12,
                      fontSize: 14,
                    }}
                  >
                    {m.pesan && <div style={{ whiteSpace: 'pre-wrap' }}>{m.pesan}</div>}
                    {m.media_url &&
                      (m.media_type === 'video' || /\.(mp4|webm)(\?|$)/i.test(m.media_url) ? (
                        <video src={m.media_url} controls style={{ maxWidth: '100%', marginTop: 6, borderRadius: 8 }} />
                      ) : (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={m.media_url} alt="" style={{ maxWidth: '100%', marginTop: 6, borderRadius: 8 }} />
                      ))}
                  </div>
                );
              })}
              <div ref={bottom} />
            </div>
            {file && (
              <div style={{ padding: '4px 14px', fontSize: 12, color: '#aaa' }}>
                📎 {file.name}{' '}
                <button
                  type="button"
                  style={{ color: '#f66', border: 0, background: 'none', cursor: 'pointer' }}
                  onClick={() => {
                    setFile(null);
                    if (fileRef.current) fileRef.current.value = '';
                  }}
                >
                  hapus
                </button>
              </div>
            )}
            <div style={{ display: 'flex', gap: 8, padding: 12, borderTop: '1px solid #222', alignItems: 'center' }}>
              <input
                ref={fileRef}
                type="file"
                accept="image/*,video/mp4,video/webm"
                style={{ display: 'none' }}
                onChange={(e) => setFile(e.target.files?.[0] || null)}
              />
              <button type="button" className="btn" onClick={() => fileRef.current?.click()} style={{ padding: '10px 12px' }}>
                📎
              </button>
              <input
                className="input"
                placeholder="Balas pesan…"
                value={text}
                onChange={(e) => setText(e.target.value)}
                style={{ flex: 1 }}
                onKeyDown={(e) => e.key === 'Enter' && kirim()}
              />
              <button className="btn btn-primary" type="button" disabled={loading} onClick={kirim}>
                Kirim
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
