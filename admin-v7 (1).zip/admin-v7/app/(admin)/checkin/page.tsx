'use client';
import { useEffect, useState } from 'react';

const defaultHadiah = [1,2,3,4,5,6,7].map((h) => ({
  hari_ke: h,
  nominal: h === 1 ? 500 : h === 2 ? 750 : h === 3 ? 1000 : h === 4 ? 1250 : h === 5 ? 1500 : h === 6 ? 2000 : 5000,
  tipe_saldo: 'dompet',
}));

export default function CheckinAdmin() {
  const [aktif, setAktif] = useState(true);
  const [mode, setMode] = useState<'statis' | 'bertahap'>('statis');
  const [defaultNominal, setDefault] = useState(1000);
  const [hadiah, setHadiah] = useState(defaultHadiah);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    (async () => {
      const d = await (await fetch('/api/modules?mod=checkin')).json();
      if (d.status !== 'sukses') return;
      setAktif(!!d.aktif);
      setMode(d.mode === 'bertahap' ? 'bertahap' : 'statis');
      setDefault(Number(d.default_nominal || 1000));
      if (d.hadiah?.length) {
        const map = new Map(d.hadiah.map((h: any) => [h.hari_ke, h]));
        setHadiah(defaultHadiah.map((h) => {
          const x = map.get(h.hari_ke) as any;
          return x ? { hari_ke: h.hari_ke, nominal: Number(x.nominal), tipe_saldo: x.tipe_saldo || 'dompet' } : h;
        }));
      }
    })();
  }, []);

  async function simpanPengaturan() {
    const d = await (await fetch('/api/modules', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mod: 'checkin', aksi: 'simpan_pengaturan', aktif, mode, default_nominal: defaultNominal }),
    })).json();
    setMsg(d.pesan);
  }
  async function simpanHadiah() {
    const d = await (await fetch('/api/modules', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mod: 'checkin', aksi: 'simpan_hadiah', items: hadiah }),
    })).json();
    setMsg(d.pesan);
  }

  return (
    <div style={{ padding: 20, maxWidth: 720 }}>
      <h1 style={{ marginBottom: 4 }}>Check-in Harian</h1>
      <p style={{ color: '#888', fontSize: 13, marginBottom: 16 }}>Client hanya melihat tombol check-in (tanpa grid hari)</p>
      {msg && <p style={{ color: '#facc15', marginBottom: 12 }}>{msg}</p>}

      <div style={card}>
        <label style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12 }}>
          <input type="checkbox" checked={aktif} onChange={(e) => setAktif(e.target.checked)} /> Aktifkan check-in
        </label>
        <label style={label}>Mode hadiah</label>
        <select style={inp} value={mode} onChange={(e) => setMode(e.target.value as any)}>
          <option value="statis">Statis — nominal sama setiap hari</option>
          <option value="bertahap">Bertahap — naik menurut streak (hari 1–7)</option>
        </select>
        <label style={{ ...label, marginTop: 12 }}>Hadiah default / hari 1 (Rp)</label>
        <input style={inp} type="number" value={defaultNominal} onChange={(e) => setDefault(Number(e.target.value))} />
        <p style={{ fontSize: 12, color: '#777', margin: '8px 0 12px' }}>Mode statis: nilai ini (atau baris hari 1) dipakai setiap hari.</p>
        <button style={btn} onClick={simpanPengaturan}>Simpan Pengaturan</button>
      </div>

      {mode === 'bertahap' && (
        <div style={{ ...card, marginTop: 16 }}>
          <h3 style={{ marginBottom: 12 }}>Hadiah bertahap (hari 1–7)</h3>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ color: '#aaa', textAlign: 'left' }}>
                <th style={th}>HARI</th><th style={th}>NOMINAL (RP)</th><th style={th}>MASUK KE</th>
              </tr>
            </thead>
            <tbody>
              {hadiah.map((h, i) => (
                <tr key={h.hari_ke} style={{ borderTop: '1px solid #222' }}>
                  <td style={td}><b>Hari {h.hari_ke}</b></td>
                  <td style={td}>
                    <input style={inp} type="number" value={h.nominal}
                      onChange={(e) => {
                        const n = [...hadiah];
                        n[i] = { ...n[i], nominal: Number(e.target.value) };
                        setHadiah(n);
                      }} />
                  </td>
                  <td style={td}>
                    <select style={inp} value={h.tipe_saldo}
                      onChange={(e) => {
                        const n = [...hadiah];
                        n[i] = { ...n[i], tipe_saldo: e.target.value };
                        setHadiah(n);
                      }}>
                      <option value="dompet">Dompet Saldo</option>
                      <option value="deposit">Saldo Deposit</option>
                      <option value="poin">Poin</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button style={{ ...btn, marginTop: 14 }} onClick={simpanHadiah}>Simpan Hadiah Bertahap</button>
        </div>
      )}
    </div>
  );
}
const card: React.CSSProperties = { background: 'rgba(255,255,255,0.04)', border: '1px solid #222', borderRadius: 14, padding: 16 };
const label: React.CSSProperties = { display: 'block', fontSize: 12, color: '#aaa', marginBottom: 6 };
const inp: React.CSSProperties = { width: '100%', padding: 10, borderRadius: 8, border: '1px solid #333', background: '#111', color: '#fff' };
const btn: React.CSSProperties = { background: '#facc15', border: 0, padding: '10px 16px', borderRadius: 8, fontWeight: 700, cursor: 'pointer', color: '#000' };
const th: React.CSSProperties = { padding: '8px 6px' };
const td: React.CSSProperties = { padding: '8px 6px' };
