'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function ProdukActions({ id, status }: { id: number; status: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function toggle() {
    setLoading(true);
    try {
      const res = await fetch('/api/produk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'produk_status',
          id,
          status: status === 'aktif' ? 'nonaktif' : 'aktif',
        }),
      });
      const data = await res.json();
      if (data.status !== 'sukses') alert(data.pesan || 'Gagal');
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  async function hapus() {
    if (!confirm('Hapus produk ini beserta data terkait?')) return;
    setLoading(true);
    try {
      const res = await fetch('/api/produk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'produk_hapus', id }),
      });
      const data = await res.json();
      if (data.status !== 'sukses') alert(data.pesan || 'Gagal');
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
      <Link href={`/produk-buat?id=${id}`} className="btn btn-primary" style={{ padding: '6px 10px', fontSize: 12 }}>
        Edit
      </Link>
      <button className="btn btn-ghost" style={{ padding: '6px 10px', fontSize: 12 }} disabled={loading} onClick={toggle}>
        {status === 'aktif' ? 'Nonaktifkan' : 'Aktifkan'}
      </button>
      <button className="btn btn-danger" style={{ padding: '6px 10px', fontSize: 12 }} disabled={loading} onClick={hapus}>
        Hapus
      </button>
    </div>
  );
}
