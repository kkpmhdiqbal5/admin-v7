import Link from 'next/link';
import { query, RowDataPacket } from '@/lib/db';
import { supabasePublicUrl } from '@/lib/supabase';
import { requireSession, hasIzin } from '@/lib/auth';
import { redirect } from 'next/navigation';
import ProdukActions from './ProdukActions';

export default async function ProdukPage() {
  const session = await requireSession();
  if (!hasIzin(session, 'produk')) redirect('/dashboard');

  const rows = await query<RowDataPacket[]>(
    `SELECT id, nama_produk, jenis_produk, harga, stok, status, gambar, created_at
     FROM produk ORDER BY id DESC LIMIT 200`
  );

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h1 className="page-title" style={{ marginBottom: 0 }}>
          Kelola Produk
        </h1>
        <Link href="/produk-buat" className="btn btn-primary">
          <i className="fa-solid fa-plus" /> Buat Produk
        </Link>
      </div>

      <div className="card table-wrap">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Gambar</th>
              <th>Nama</th>
              <th>Jenis</th>
              <th>Harga</th>
              <th>Stok</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr>
                <td colSpan={8} style={{ color: 'var(--muted)', textAlign: 'center' }}>
                  Belum ada produk. Buat produk baru dulu.
                </td>
              </tr>
            )}
            {rows.map((p) => {
              const img = supabasePublicUrl(p.gambar as string);
              return (
                <tr key={p.id}>
                  <td>#{p.id}</td>
                  <td>
                    {img ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={img}
                        alt=""
                        style={{ width: 40, height: 40, objectFit: 'cover', borderRadius: 8 }}
                      />
                    ) : (
                      <span style={{ color: 'var(--muted)' }}>—</span>
                    )}
                  </td>
                  <td>{p.nama_produk}</td>
                  <td>{p.jenis_produk}</td>
                  <td>Rp {Number(p.harga).toLocaleString('id-ID')}</td>
                  <td>{p.stok}</td>
                  <td>
                    <span className={`badge ${p.status === 'aktif' ? 'aktif' : 'nonaktif'}`}>
                      {p.status}
                    </span>
                  </td>
                  <td>
                    <ProdukActions id={Number(p.id)} status={String(p.status)} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
