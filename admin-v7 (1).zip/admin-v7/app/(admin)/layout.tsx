import { redirect } from 'next/navigation';
import { getSession, requireSession } from '@/lib/auth';
import Sidebar from '@/components/Sidebar';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  let session;
  try {
    session = await requireSession();
  } catch {
    redirect('/login');
  }

  return (
    <div className="shell">
      <Sidebar username={session.username} role={session.role} izin={session.izin} />
      <main className="main">{children}</main>
    </div>
  );
}
