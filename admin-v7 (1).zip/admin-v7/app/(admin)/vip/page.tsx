'use client';
import { useEffect, useState } from 'react';

type Level = { id?: number; level: number; nama: string; min_anggota: number; min_belanja: number };

export default function VipPage() {
  const [rows, setRows] = useState<Level[]>([]);
  const [msg, setMsg] = useState('');

  async function load() {
    const d = await (await fetch('/api/modules?mod=vip')).json();
    if (d.status === 'sukses') {
      setRows(
        (d.data || []).map((r: any) => ({
          id: r.id,
          level: Number(r.level),
          nama: String(r.nama || r.nama_level || `VIP${r.level}`),
          min_anggota: Number(r.min_anggota || r.min_member || 0),
          min_belanja: Number(r.min_belanja || r.min_spending || 0),
        }))
      );
    }
  }
  useEffect(() => {
    load().catch(() => {});
  }, []);

  function update(i: number, k: keyof Level, v: string | number) {
    setRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, [k]: v } : r)));
  }

  function tambah() {
    const next = rows.length ? Math.max(...rows.map((r) => r.level)) + 1 : 1;
    setRows((prev) => [...prev, { level: next, nama: `VIP${next}`, min_anggota: 0, min_belanja: 0 }]);
  }

  function hapus(i: number) {
    setRows((prev) => prev.filter((_, idx) => idx !== i));
  }

  async function simpan() {
    const d = await (
      await fetch('/api/modules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mod: 'vip', aksi: 'simpan_semua', levels: rows }),
      })
    ).json();
    setMsg(d.pesan || d.status);
    if (d.status === 'sukses') load();
  }

  return (
    <div>
      <h1 className="page-title">Tingkat VIP</h1>
      <p style={{ color: 'var(--muted)', marginBottom: 14, fontSize: 13 }}>
        Atur syarat upgrade tiap level VIP. Level bisa ditambah atau diubah kapan saja.
      </p>
      {msg && <div className="alert" style={{ marginBottom: 12 }}>{msg}</div>}
      <div className="card">
        <div style={{ display: 'grid', gridTemplateColumns: '60px 1fr 1fr 1fr 70px', gap: 8, marginBottom: 8, fontSize: 12, color: 'var(--muted)' }}>
          <span>LEVEL</span><span>NAMA</span><span>MIN. ANGGOTA</span><span>MIN. BELANJA (Rp)</span><span></span>
        </div>
        {rows.map((r, i) => (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '60px 1fr 1fr 1fr 70px', gap: 8, marginBottom: 8 }}>
            <input className="input" type="number" value={r.level} onChange={(e) => update(i, 'level', Number(e.target.value))} />
            <input className="input" value={r.nama} onChange={(e) => update(i, 'nama', e.target.value)} />
            <input className="input" type="number" value={r.min_anggota} onChange={(e) => update(i, 'min_anggota', Number(e.target.value))} />
            <input className="input" type="number" value={r.min_belanja} onChange={(e) => update(i, 'min_belanja', Number(e.target.value))} />
            <button type="button" className="btn btn-ghost" onClick={() => hapus(i)}>Hapus</button>
          </div>
        ))}
        <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
          <button type="button" className="btn" onClick={tambah}>+ Tambah Level</button>
          <button type="button" className="btn btn-primary" onClick={simpan}>Simpan Perubahan</button>
        </div>
      </div>
    </div>
  );
}
