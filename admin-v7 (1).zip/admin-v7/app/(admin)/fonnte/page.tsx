'use client';
import { useEffect, useState } from 'react';

export default function FonntePage() {
  const [form, setForm] = useState({
    fonnte_token: '',
    fonnte_country: '62',
    fonnte_aktif: '1',
    otp_template:
      '*KODE VERIFIKASI (OTP)*\n\nKode OTP Anda adalah: *{kode}*\n\nJangan berikan kode ini kepada siapa pun.',
    smtp_host: '',
    smtp_user: '',
    smtp_pass: '',
    smtp_from: '',
    email_otp_aktif: '0',
  });
  const [targetTes, setTargetTes] = useState('');
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch('/api/modules?mod=fonnte')
      .then((r) => r.json())
      .then((d) => {
        if (d.status === 'sukses' && d.data) {
          setForm((f) => ({
            ...f,
            ...Object.fromEntries(
              Object.entries(d.data).map(([k, v]) => [k, v == null ? '' : String(v)])
            ),
          }));
        }
      })
      .catch(() => {});
  }, []);

  function set(k: string, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function simpan() {
    setLoading(true);
    setMsg('');
    try {
      const d = await (
        await fetch('/api/modules', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ mod: 'fonnte', aksi: 'simpan', ...form }),
        })
      ).json();
      setMsg(d.pesan || d.status);
    } catch {
      setMsg('Gagal simpan');
    }
    setLoading(false);
  }

  async function tesKirim() {
    setLoading(true);
    setMsg('');
    try {
      const d = await (
        await fetch('/api/modules', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mod: 'fonnte',
            aksi: 'tes',
            fonnte_token: form.fonnte_token,
            fonnte_country: form.fonnte_country,
            target: targetTes,
          }),
        })
      ).json();
      setMsg(d.pesan || d.status);
    } catch {
      setMsg('Gagal tes kirim');
    }
    setLoading(false);
  }

  return (
    <div>
      <h1 className="page-title">API OTP — Fonnte & Email</h1>
      <p style={{ color: 'var(--muted)', marginBottom: 16, fontSize: 13 }}>
        Token Fonnte dipakai otomatis saat client <b>daftar</b>, <b>reset password</b>, atau{' '}
        <b>ubah kontak</b> (OTP WhatsApp). Sama seperti PHP <code>kirimWhatsAppOTP</code>.
      </p>

      {msg && (
        <div className="alert" style={{ marginBottom: 12 }}>
          {msg}
        </div>
      )}

      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 12 }}>WhatsApp — Fonnte</h3>
        <label style={{ display: 'block', marginBottom: 6, fontSize: 12, color: 'var(--muted)' }}>
          Token API Fonnte
        </label>
        <input
          className="input"
          style={{ width: '100%', marginBottom: 12 }}
          value={form.fonnte_token}
          onChange={(e) => set('fonnte_token', e.target.value)}
          placeholder="Token dari panel fonnte.com"
        />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div>
            <label style={{ fontSize: 12, color: 'var(--muted)' }}>Kode negara</label>
            <input
              className="input"
              style={{ width: '100%' }}
              value={form.fonnte_country}
              onChange={(e) => set('fonnte_country', e.target.value)}
            />
          </div>
          <div>
            <label style={{ fontSize: 12, color: 'var(--muted)' }}>Aktifkan Fonnte</label>
            <select
              className="input"
              style={{ width: '100%' }}
              value={form.fonnte_aktif}
              onChange={(e) => set('fonnte_aktif', e.target.value)}
            >
              <option value="1">Aktif</option>
              <option value="0">Nonaktif (simulasi)</option>
            </select>
          </div>
        </div>
        <label style={{ display: 'block', marginTop: 12, marginBottom: 6, fontSize: 12, color: 'var(--muted)' }}>
          Template pesan OTP (pakai {'{kode}'} untuk nomor OTP)
        </label>
        <textarea
          className="input"
          rows={5}
          style={{ width: '100%' }}
          value={form.otp_template}
          onChange={(e) => set('otp_template', e.target.value)}
        />
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 12 }}>Tes kirim WhatsApp</h3>
        <input
          className="input"
          style={{ width: '100%', marginBottom: 10 }}
          placeholder="Nomor HP tujuan tes (08… / 62…)"
          value={targetTes}
          onChange={(e) => setTargetTes(e.target.value)}
        />
        <button className="btn" type="button" disabled={loading} onClick={tesKirim}>
          Kirim pesan tes
        </button>
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 12 }}>Email OTP (opsional)</h3>
        <select
          className="input"
          style={{ width: '100%', marginBottom: 10 }}
          value={form.email_otp_aktif}
          onChange={(e) => set('email_otp_aktif', e.target.value)}
        >
          <option value="0">Nonaktif</option>
          <option value="1">Aktif</option>
        </select>
        <input
          className="input"
          style={{ width: '100%', marginBottom: 8 }}
          placeholder="SMTP Host"
          value={form.smtp_host}
          onChange={(e) => set('smtp_host', e.target.value)}
        />
        <input
          className="input"
          style={{ width: '100%', marginBottom: 8 }}
          placeholder="SMTP User"
          value={form.smtp_user}
          onChange={(e) => set('smtp_user', e.target.value)}
        />
        <input
          className="input"
          style={{ width: '100%', marginBottom: 8 }}
          type="password"
          placeholder="SMTP Pass (kosongkan jika tidak diubah)"
          value={form.smtp_pass}
          onChange={(e) => set('smtp_pass', e.target.value)}
        />
        <input
          className="input"
          style={{ width: '100%' }}
          placeholder="From email"
          value={form.smtp_from}
          onChange={(e) => set('smtp_from', e.target.value)}
        />
      </div>

      <button className="btn btn-primary" type="button" disabled={loading} onClick={simpan}>
        {loading ? 'Menyimpan…' : 'Simpan pengaturan'}
      </button>
    </div>
  );
}
