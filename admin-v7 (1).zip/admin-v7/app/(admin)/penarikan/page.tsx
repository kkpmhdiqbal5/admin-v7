'use client';

import { useEffect, useMemo, useState } from 'react';

type Row = {
  id: number;
  username?: string;
  nominal: number;
  fee?: number;
  status: string;
  nama_bank?: string;
  no_rekening?: string;
  nama_ktp?: string;
  no_hp?: string;
  email?: string;
  created_at?: string;
  catatan?: string;
};

type Settings = {
  min_tarik: number;
  fee_persen: number;
  fee_tetap: number;
  mode_penarikan: string;
  payment_out_provider: string;
  payment_out_key: string;
  payment_out_auto: string;
};

export default function PenarikanAdminPage() {
  const [rows, setRows] = useState<Row[]>([]);
  const [msg, setMsg] = useState('');
  const [dari, setDari] = useState('');
  const [sampai, setSampai] = useState('');
  const [status, setStatus] = useState('');
  const [selected, setSelected] = useState<number[]>([]);
  const [settings, setSettings] = useState<Settings>({
    min_tarik: 10000,
    fee_persen: 0,
    fee_tetap: 0,
    mode_penarikan: 'manual',
    payment_out_provider: '',
    payment_out_key: '',
    payment_out_auto: '0',
  });

  async function load() {
    const q = new URLSearchParams();
    if (dari) q.set('dari', dari);
    if (sampai) q.set('sampai', sampai);
    if (status) q.set('status', status);
    const res = await fetch('/api/penarikan?' + q.toString());
    const data = await res.json();
    if (data.status === 'sukses') {
      setRows(data.data || []);
      if (data.settings) setSettings({ ...settings, ...data.settings });
    }
  }

  useEffect(() => {
    load();
  }, []);

  function toggle(id: number) {
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  }

  function toggleAll() {
    if (selected.length === rows.length) setSelected([]);
    else setSelected(rows.map((r) => r.id));
  }

  function exportCsv() {
    const list = selected.length ? rows.filter((r) => selected.includes(r.id)) : rows;
    const header = ['id', 'username', 'nama_ktp', 'bank', 'rekening', 'no_hp', 'nominal', 'fee', 'status', 'tanggal'];
    const lines = [header.join(',')];
    for (const r of list) {
      lines.push(
        [
          r.id,
          r.username || '',
          r.nama_ktp || '',
          r.nama_bank || '',
          r.no_rekening || '',
          r.no_hp || '',
          r.nominal,
          r.fee || 0,
          r.status,
          r.created_at || '',
        ]
          .map((x) => `"${String(x).replace(/"/g, '""')}"`)
          .join(',')
      );
    }
    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `rekapan-penarikan-${dari || 'all'}-${sampai || 'all'}.csv`;
    a.click();
  }

  async function aksi(id: number, aksi: string) {
    const res = await fetch('/api/penarikan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, aksi }),
    });
    const data = await res.json();
    setMsg(data.pesan || data.status);
    load();
  }

  async function bulk(status_aksi: string) {
    if (!selected.length) return;
    const res = await fetch('/api/penarikan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ aksi: 'bulk', ids: selected, status_aksi }),
    });
    const data = await res.json();
    setMsg(data.pesan || data.status);
    setSelected([]);
    load();
  }

  async function saveSetting() {
    const res = await fetch('/api/penarikan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ aksi: 'simpan_setting', ...settings, payment_out_auto: settings.payment_out_auto === '1' }),
    });
    const data = await res.json();
    setMsg(data.pesan || data.status);
  }

  const contoh = useMemo(() => {
    const n = 100000;
    const fee = Math.floor((n * settings.fee_persen) / 100) + settings.fee_tetap;
    return { n, fee, bersih: n - fee };
  }, [settings]);

  return (
    <div>
      <h1 className="page-title">Penarikan</h1>
      {msg && <div className="alert sukses" style={{ marginBottom: 12 }}>{msg}</div>}

      {/* Settings */}
      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 12 }}>Pengaturan penarikan & payment-out</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))', gap: 10 }}>
          <div>
            <label className="label">Minimal tarik (Rp)</label>
            <input className="input" type="number" value={settings.min_tarik} onChange={(e) => setSettings({ ...settings, min_tarik: Number(e.target.value) || 0 })} />
          </div>
          <div>
            <label className="label">Fee persen (%)</label>
            <input className="input" type="number" step="0.1" value={settings.fee_persen} onChange={(e) => setSettings({ ...settings, fee_persen: Number(e.target.value) || 0 })} />
          </div>
          <div>
            <label className="label">Fee tetap (Rp)</label>
            <input className="input" type="number" value={settings.fee_tetap} onChange={(e) => setSettings({ ...settings, fee_tetap: Number(e.target.value) || 0 })} />
          </div>
          <div>
            <label className="label">Mode</label>
            <select className="input" value={settings.mode_penarikan} onChange={(e) => setSettings({ ...settings, mode_penarikan: e.target.value })}>
              <option value="manual">Manual</option>
              <option value="gateway">API Gateway</option>
            </select>
          </div>
          <div>
            <label className="label">Provider payment-out</label>
            <input className="input" value={settings.payment_out_provider} onChange={(e) => setSettings({ ...settings, payment_out_provider: e.target.value })} placeholder="ipaymu / xendit / ..." />
          </div>
          <div>
            <label className="label">API Key payment-out</label>
            <input className="input" value={settings.payment_out_key} onChange={(e) => setSettings({ ...settings, payment_out_key: e.target.value })} placeholder="secret key" />
          </div>
        </div>
        <label style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 10, fontSize: 13 }}>
          <input type="checkbox" checked={settings.payment_out_auto === '1'} onChange={(e) => setSettings({ ...settings, payment_out_auto: e.target.checked ? '1' : '0' })} />
          Auto-konfirmasi setelah dikirim via gateway
        </label>
        <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 8 }}>
          Contoh kalkulasi: tarik Rp {contoh.n.toLocaleString('id-ID')} → fee Rp {contoh.fee.toLocaleString('id-ID')} → bersih Rp {contoh.bersih.toLocaleString('id-ID')}
        </p>
        <button className="btn btn-primary" type="button" onClick={saveSetting} style={{ marginTop: 10 }}>
          Simpan pengaturan
        </button>
      </div>

      {/* Filter */}
      <div className="card" style={{ marginBottom: 16, display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'end' }}>
        <div>
          <label className="label">Dari tanggal</label>
          <input className="input" type="date" value={dari} onChange={(e) => setDari(e.target.value)} />
        </div>
        <div>
          <label className="label">Sampai tanggal</label>
          <input className="input" type="date" value={sampai} onChange={(e) => setSampai(e.target.value)} />
        </div>
        <div>
          <label className="label">Status</label>
          <select className="input" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Semua</option>
            <option value="menunggu">Menunggu</option>
            <option value="diproses">Diproses</option>
            <option value="berhasil">Berhasil</option>
            <option value="ditolak">Ditolak</option>
          </select>
        </div>
        <button className="btn btn-primary" type="button" onClick={load}>
          Filter
        </button>
        <button className="btn btn-ghost" type="button" onClick={exportCsv}>
          Unduh CSV {selected.length ? `(${selected.length})` : '(semua)'}
        </button>
        {selected.length > 0 && (
          <>
            <button className="btn btn-primary" type="button" onClick={() => bulk('berhasil')}>
              Bulk berhasil
            </button>
            <button className="btn btn-ghost" type="button" onClick={() => bulk('ditolak')}>
              Bulk tolak
            </button>
          </>
        )}
      </div>

      <div style={{ marginBottom: 8 }}>
        <label style={{ fontSize: 13, display: 'flex', gap: 8, alignItems: 'center' }}>
          <input type="checkbox" checked={selected.length === rows.length && rows.length > 0} onChange={toggleAll} />
          Pilih semua ({rows.length})
        </label>
      </div>

      <div style={{ display: 'grid', gap: 10 }}>
        {rows.map((r) => (
          <div
            key={r.id}
            className="card"
            style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}
          >
            <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
              <input type="checkbox" checked={selected.includes(r.id)} onChange={() => toggle(r.id)} style={{ marginTop: 4 }} />
              <div>
                <div style={{ fontWeight: 700 }}>{r.username || `#${r.id}`}</div>
                <div style={{ color: 'var(--primary)', fontWeight: 700 }}>Rp {Number(r.nominal).toLocaleString('id-ID')}</div>
                <div style={{ fontSize: 12, color: '#ccc', marginTop: 4 }}>
                  <b>Bank:</b> {r.nama_ktp || '—'} · {r.nama_bank || '—'} · {r.no_rekening || '—'}
                </div>
                <div style={{ fontSize: 11, color: '#888' }}>
                  {r.no_hp || ''} {r.email ? `· ${r.email}` : ''} · {String(r.created_at || '').slice(0, 16)}
                </div>
                <div style={{ fontSize: 11, color: '#aaa' }}>Status: {r.status}</div>
              </div>
            </div>
            {r.status === 'menunggu' && (
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <button className="btn btn-primary" type="button" onClick={() => aksi(r.id, 'berhasil')}>
                  Berhasil
                </button>
                <button className="btn btn-ghost" type="button" onClick={() => aksi(r.id, 'kirim_gateway')}>
                  Kirim gateway
                </button>
                <button className="btn btn-ghost" type="button" onClick={() => aksi(r.id, 'ditolak')}>
                  Tolak
                </button>
              </div>
            )}
          </div>
        ))}
        {rows.length === 0 && <p style={{ color: '#888' }}>Tidak ada data</p>}
      </div>
    </div>
  );
}
