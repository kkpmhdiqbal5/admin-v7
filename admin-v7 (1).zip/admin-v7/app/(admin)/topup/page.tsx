'use client';

import { useEffect, useState } from 'react';

type Row = {
  id: number;
  username?: string;
  nominal: number;
  nominal_transfer?: number;
  status: string;
  email?: string;
  no_hp?: string;
  created_at?: string;
  metode?: string;
};

export default function TopupAdminPage() {
  const [rows, setRows] = useState<Row[]>([]);
  const [msg, setMsg] = useState('');
  const [dari, setDari] = useState('');
  const [sampai, setSampai] = useState('');
  const [status, setStatus] = useState('');
  const [selected, setSelected] = useState<number[]>([]);

  async function load() {
    const q = new URLSearchParams();
    if (dari) q.set('dari', dari);
    if (sampai) q.set('sampai', sampai);
    if (status) q.set('status', status);
    const res = await fetch('/api/topup?' + q.toString());
    const data = await res.json();
    if (data.status === 'sukses') setRows(data.data || []);
  }

  useEffect(() => {
    load();
  }, []);

  function toggle(id: number) {
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  }

  function exportCsv() {
    const list = selected.length ? rows.filter((r) => selected.includes(r.id)) : rows;
    const lines = ['id,username,nominal,transfer,status,hp,email,tanggal'];
    for (const r of list) {
      lines.push(
        [r.id, r.username, r.nominal, r.nominal_transfer || '', r.status, r.no_hp || '', r.email || '', r.created_at || '']
          .map((x) => `"${String(x).replace(/"/g, '""')}"`)
          .join(',')
      );
    }
    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `rekapan-topup-${dari || 'all'}-${sampai || 'all'}.csv`;
    a.click();
  }

  async function aksi(id: number, aksi: string) {
    setMsg('');
    const res = await fetch('/api/topup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, aksi }),
    });
    const data = await res.json();
    setMsg(data.pesan || data.status);
    load();
  }

  async function bulk(status_aksi: string) {
    const res = await fetch('/api/topup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ aksi: 'bulk', ids: selected, status_aksi }),
    });
    const data = await res.json();
    setMsg(data.pesan || data.status);
    setSelected([]);
    load();
  }

  return (
    <div>
      <h1 className="page-title">Top Up Request</h1>
      {msg && <div className="alert sukses" style={{ marginBottom: 12 }}>{msg}</div>}

      <div className="card" style={{ marginBottom: 16, display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'end' }}>
        <div>
          <label className="label">Dari</label>
          <input className="input" type="date" value={dari} onChange={(e) => setDari(e.target.value)} />
        </div>
        <div>
          <label className="label">Sampai</label>
          <input className="input" type="date" value={sampai} onChange={(e) => setSampai(e.target.value)} />
        </div>
        <div>
          <label className="label">Status</label>
          <select className="input" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Semua</option>
            <option value="menunggu">Menunggu</option>
            <option value="dikonfirmasi">Dikonfirmasi</option>
            <option value="ditolak">Ditolak</option>
          </select>
        </div>
        <button className="btn btn-primary" type="button" onClick={load}>
          Filter
        </button>
        <button className="btn btn-ghost" type="button" onClick={exportCsv}>
          Unduh CSV {selected.length ? `(${selected.length})` : ''}
        </button>
        {selected.length > 0 && (
          <>
            <button className="btn btn-primary" type="button" onClick={() => bulk('konfirmasi')}>
              Bulk konfirmasi
            </button>
            <button className="btn btn-ghost" type="button" onClick={() => bulk('tolak')}>
              Bulk tolak
            </button>
          </>
        )}
      </div>

      <div style={{ display: 'grid', gap: 10 }}>
        {rows.map((r) => (
          <div key={r.id} className="card" style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', gap: 12 }}>
              <input type="checkbox" checked={selected.includes(r.id)} onChange={() => toggle(r.id)} />
              <div>
                <div style={{ fontWeight: 700 }}>{r.username || `User#${r.id}`}</div>
                <div style={{ color: 'var(--primary)', fontWeight: 700 }}>Rp {Number(r.nominal).toLocaleString('id-ID')}</div>
                <div style={{ fontSize: 12, color: '#888' }}>
                  {r.no_hp || ''} {r.email ? `· ${r.email}` : ''} · {String(r.created_at || '').slice(0, 16)}
                </div>
                <div style={{ fontSize: 11, color: '#aaa' }}>{r.status}</div>
              </div>
            </div>
            {r.status === 'menunggu' && (
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-primary" type="button" onClick={() => aksi(r.id, 'konfirmasi')}>
                  Konfirmasi
                </button>
                <button className="btn btn-ghost" type="button" onClick={() => aksi(r.id, 'tolak')}>
                  Tolak
                </button>
              </div>
            )}
          </div>
        ))}
        {rows.length === 0 && <p style={{ color: '#888' }}>Belum ada request</p>}
      </div>
    </div>
  );
}
