'use client';
import { useEffect, useState } from 'react';

const DEFAULTS = {
  brand: 'V7 App',
  logo: '',
  primary: '#22c55e',
  bg: '#050505',
  text: '#ffffff',
  muted: '#888888',
  button: '#22c55e',
  button_text: '#000000',
  card: '#121212',
  border: '#333333',
  bg_image: '',
  overlay: '0.65',
  // per-page accents (opsional)
  login_bg: '',
  dashboard_accent: '',
  topup_accent: '',
  produk_accent: '',
  success: '#22c55e',
  danger: '#dc3545',
  warning: '#facc15',
  radius: '14',
  font_size: '14',
  nav_bg: '#0a0a0a',
  input_bg: '#111111',
};

export default function TampilanPage() {
  const [form, setForm] = useState({ ...DEFAULTS });
  const [msg, setMsg] = useState('');

  useEffect(() => {
    fetch('/api/modules?mod=tampilan')
      .then((r) => r.json())
      .then((d) => {
        if (d.status === 'sukses' && d.data) {
          setForm((f) => ({
            ...f,
            brand: d.data.brand || f.brand,
            logo: d.data.logo || '',
            primary: d.data.primary || f.primary,
            bg: d.data.bg || f.bg,
            text: d.data.text || f.text,
            muted: d.data.muted || f.muted,
            button: d.data.button || d.data.primary || f.button,
            button_text: d.data.button_text || f.button_text,
            card: d.data.card || f.card,
            border: d.data.border || f.border,
            bg_image: d.data.bg_image || '',
            overlay: d.data.overlay || '0.65',
            login_bg: d.data.login_bg || '',
            dashboard_accent: d.data.dashboard_accent || '',
            topup_accent: d.data.topup_accent || '',
            produk_accent: d.data.produk_accent || '',
          }));
        }
      })
      .catch(() => {});
  }, []);

  function set(k: string, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function simpan() {
    const d = await (
      await fetch('/api/modules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mod: 'tampilan', aksi: 'simpan', ...form }),
      })
    ).json();
    setMsg(d.pesan || d.status);
  }

  const Color = ({ label, k }: { label: string; k: keyof typeof DEFAULTS }) => (
    <div>
      <label className="label">{label}</label>
      <div style={{ display: 'flex', gap: 8 }}>
        <input type="color" value={form[k] || '#000000'} onChange={(e) => set(k, e.target.value)} style={{ width: 44, height: 36, border: 'none', background: 'transparent' }} />
        <input className="input" value={form[k]} onChange={(e) => set(k, e.target.value)} style={{ flex: 1 }} />
      </div>
    </div>
  );

  return (
    <div>
      <h1 className="page-title">Tampilan Web Client</h1>
      <p style={{ color: 'var(--muted)', fontSize: 13, marginBottom: 14 }}>
        Nama, logo, warna tombol, background, dan aksen per halaman yang dilihat member.
      </p>
      {msg && <div className="alert" style={{ marginBottom: 12 }}>{msg}</div>}

      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 12 }}>Brand & Logo</h3>
        <label className="label">Nama Situs / Brand</label>
        <input className="input" value={form.brand} onChange={(e) => set('brand', e.target.value)} style={{ width: '100%', marginBottom: 10 }} />
        <label className="label">Logo (URL Supabase / CDN)</label>
        <input className="input" value={form.logo} onChange={(e) => set('logo', e.target.value)} placeholder="https://..." style={{ width: '100%', marginBottom: 10 }} />
        <label className="label">Gambar Latar Belakang (URL)</label>
        <input className="input" value={form.bg_image} onChange={(e) => set('bg_image', e.target.value)} style={{ width: '100%', marginBottom: 10 }} />
        <label className="label">Overlay gelap (0–1)</label>
        <input className="input" value={form.overlay} onChange={(e) => set('overlay', e.target.value)} style={{ width: '100%' }} />
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 12 }}>Warna Global</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Color label="Warna Primer" k="primary" />
          <Color label="Warna Latar" k="bg" />
          <Color label="Warna Teks" k="text" />
          <Color label="Teks muted" k="muted" />
          <Color label="Warna Tombol" k="button" />
          <Color label="Teks Tombol" k="button_text" />
          <Color label="Warna Kartu" k="card" />
          <Color label="Warna Border" k="border" />
          <Color label="Sukses" k="success" />
          <Color label="Bahaya / error" k="danger" />
          <Color label="Peringatan" k="warning" />
          <Color label="Nav bawah / sidebar" k="nav_bg" />
          <Color label="Background input" k="input_bg" />
        </div>
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 12 }}>Aksen per Halaman Client (opsional)</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div>
            <label className="label">Login — BG image URL</label>
            <input className="input" value={form.login_bg} onChange={(e) => set('login_bg', e.target.value)} style={{ width: '100%' }} />
          </div>
          <Color label="Dashboard aksen" k="dashboard_accent" />
          <Color label="Top Up aksen" k="topup_accent" />
          <Color label="Produk aksen" k="produk_accent" />
        </div>
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 12 }}>Ukuran & bentuk</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div>
            <label className="label">Radius sudut (px)</label>
            <input className="input" value={form.radius} onChange={(e) => set('radius', e.target.value)} style={{ width: '100%' }} />
          </div>
          <div>
            <label className="label">Ukuran font dasar (px)</label>
            <input className="input" value={form.font_size} onChange={(e) => set('font_size', e.target.value)} style={{ width: '100%' }} />
          </div>
        </div>
      </div>

      <button className="btn btn-primary" type="button" onClick={simpan}>
        Simpan Tampilan
      </button>
    </div>
  );
}
