'use client';
import { useEffect, useState } from 'react';

export default function RedeemAdmin() {
  const [rows, setRows] = useState<any[]>([]);
  const [username, setUsername] = useState('');
  const [nominal, setNominal] = useState('10000');
  const [tipe, setTipe] = useState('deposit');
  const [msg, setMsg] = useState('');

  async function load() {
    const d = await (await fetch('/api/modules?mod=redeem')).json();
    if (d.status === 'sukses') setRows(d.data || []);
  }
  useEffect(() => { load(); }, []);

  async function buat() {
    const d = await (await fetch('/api/modules', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mod: 'redeem', aksi: 'buat', username, nominal: Number(nominal), tipe_saldo: tipe }),
    })).json();
    setMsg(d.pesan + (d.kode ? ` → ${d.kode}` : ''));
    if (d.status === 'sukses') { setUsername(''); load(); }
  }

  return (
    <div style={{ padding: 20 }}>
      <h1 style={{ marginBottom: 4 }}>Kode Redeem</h1>
      <p style={{ color: '#888', fontSize: 13, marginBottom: 16 }}>Buat kode redeem untuk user tertentu</p>
      {msg && <p style={{ color: '#facc15' }}>{msg}</p>}
      <div style={card}>
        <h3 style={{ marginBottom: 12 }}>Buat Kode Baru</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
          <div>
            <label style={label}>Username Tujuan</label>
            <input style={inp} placeholder="username member" value={username} onChange={(e) => setUsername(e.target.value)} />
          </div>
          <div>
            <label style={label}>Nominal (Rp)</label>
            <input style={inp} type="number" value={nominal} onChange={(e) => setNominal(e.target.value)} />
          </div>
          <div>
            <label style={label}>Tipe Saldo</label>
            <select style={inp} value={tipe} onChange={(e) => setTipe(e.target.value)}>
              <option value="deposit">Saldo Deposit</option>
              <option value="dompet">Dompet Saldo</option>
            </select>
          </div>
        </div>
        <button style={{ ...btn, marginTop: 12 }} onClick={buat}>+ Buat Kode</button>
      </div>
      <div style={{ ...card, marginTop: 16, overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ color: '#facc15', textAlign: 'left' }}>
              <th style={th}>KODE</th><th style={th}>USER</th><th style={th}>NOMINAL</th><th style={th}>TIPE</th><th style={th}>STATUS</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={5} style={{ ...td, color: '#888', textAlign: 'center' }}>Belum ada kode redeem</td></tr>}
            {rows.map((r) => (
              <tr key={r.id} style={{ borderTop: '1px solid #222' }}>
                <td style={td}><b>{r.kode}</b></td>
                <td style={td}>{r.username_tujuan || '—'}</td>
                <td style={td}>Rp {Number(r.nominal).toLocaleString('id-ID')}</td>
                <td style={td}>{r.tipe_saldo}</td>
                <td style={td}>{r.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
const card: React.CSSProperties = { background: 'rgba(255,255,255,0.04)', border: '1px solid #222', borderRadius: 14, padding: 16 };
const label: React.CSSProperties = { display: 'block', fontSize: 12, color: '#aaa', marginBottom: 6 };
const inp: React.CSSProperties = { width: '100%', padding: 10, borderRadius: 8, border: '1px solid #333', background: '#111', color: '#fff' };
const btn: React.CSSProperties = { background: '#facc15', border: 0, padding: '10px 16px', borderRadius: 8, fontWeight: 700, cursor: 'pointer', color: '#000' };
const th: React.CSSProperties = { padding: '8px 6px' };
const td: React.CSSProperties = { padding: '10px 6px' };
