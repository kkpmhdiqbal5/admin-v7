'use client';
import { useEffect, useMemo, useState, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';

const UNITS = [
  { label: 'Menit', value: 1 },
  { label: 'Jam', value: 60 },
  { label: 'Hari', value: 1440 },
];

function ProdukBuatInner() {
  const search = useSearchParams();
  const editId = Number(search.get('id') || 0);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<'idle' | 'sukses' | 'error'>('idle');
  const [pesan, setPesan] = useState('');
  const [nama, setNama] = useState('');
  const [jenis, setJenis] = useState('');
  const [deskripsi, setDeskripsi] = useState('');
  const [harga, setHarga] = useState('');
  const [stok, setStok] = useState('0');
  const [file, setFile] = useState<File | null>(null);
  const [gambarUrl, setGambarUrl] = useState('');
  const [durasi, setDurasi] = useState(0);
  const [durasiUnit, setDurasiUnit] = useState(1440);
  const [interval, setIntervalVal] = useState(0);
  const [intervalUnit, setIntervalUnit] = useState(1);
  const [saldoKlaim, setSaldoKlaim] = useState(0);
  const [maxKlaim, setMaxKlaim] = useState(0);
  const [produkStatus, setProdukStatus] = useState('nonaktif');
  const [levelProduk, setLevelProduk] = useState(1);
  const [levelSyarat, setLevelSyarat] = useState<'pernah' | 'aktif'>('pernah');
  const [maxBeliPerUser, setMaxBeliPerUser] = useState(0);

  useEffect(() => {
    if (!editId) return;
    (async () => {
      try {
        const res = await fetch('/api/produk?id=' + editId);
        const d = await res.json();
        const p = d.data || d.produk;
        if (d.status === 'sukses' && p) {
          setNama(String(p.nama_produk || ''));
          setJenis(String(p.jenis_produk || ''));
          setDeskripsi(String(p.deskripsi || ''));
          setHarga(String(p.harga ?? ''));
          setStok(String(p.stok ?? '0'));
          setGambarUrl(String(p.gambar_url || p.gambar || ''));
          setSaldoKlaim(Number(p.saldo_per_klaim || 0));
          setMaxKlaim(Number(p.max_klaim || 0));
          setProdukStatus(p.status === 'aktif' ? 'aktif' : 'nonaktif');
          setLevelProduk(Number(p.level_produk || 1));
          setLevelSyarat(p.level_syarat === 'aktif' ? 'aktif' : 'pernah');
          setMaxBeliPerUser(Number(p.max_beli_per_user || 0));
          const dm = Number(p.durasi_aktif_menit || 0);
          const im = Number(p.interval_aktif_menit || 0);
          if (dm >= 1440 && dm % 1440 === 0) { setDurasi(dm / 1440); setDurasiUnit(1440); }
          else if (dm >= 60 && dm % 60 === 0) { setDurasi(dm / 60); setDurasiUnit(60); }
          else { setDurasi(dm); setDurasiUnit(1); }
          if (im >= 1440 && im % 1440 === 0) { setIntervalVal(im / 1440); setIntervalUnit(1440); }
          else if (im >= 60 && im % 60 === 0) { setIntervalVal(im / 60); setIntervalUnit(60); }
          else { setIntervalVal(im); setIntervalUnit(1); }
        }
      } catch { /* ignore */ }
    })();
  }, [editId]);

  const durMenit = durasi * durasiUnit;
  const intMenit = interval * intervalUnit;

  const ringkas = useMemo(() => {
    const fmt = (m: number) => {
      if (m <= 0) return 'tanpa batas';
      const d = Math.floor(m / 1440);
      const h = Math.floor((m % 1440) / 60);
      const mm = m % 60;
      return [d && d + ' hari', h && h + ' jam', mm && mm + ' menit'].filter(Boolean).join(' ');
    };
    let t =
      durMenit === 0
        ? 'Setelah dibeli, produk aktif terus tanpa batas waktu.'
        : `Aktif selama ${fmt(durMenit)} setelah dibeli.`;
    if (intMenit > 0) {
      t += ` Client bisa klaim +Rp ${saldoKlaim.toLocaleString('id-ID')} tiap ${fmt(intMenit)}.`;
      if (maxKlaim > 0) t += ` Maksimal ${maxKlaim}x klaim.`;
    }
    return t;
  }, [durMenit, intMenit, saldoKlaim, maxKlaim]);

  async function parseJson(res: Response) {
    const text = await res.text();
    try {
      return { ok: res.ok, data: JSON.parse(text), raw: text, status: res.status };
    } catch {
      return {
        ok: false,
        data: { status: 'error', pesan: text || `HTTP ${res.status}` },
        raw: text,
        status: res.status,
      };
    }
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setStatus('idle');
    setPesan('');

    const h = Number(harga);
    const s = Number(stok);
    if (!nama.trim() || !(h > 0) || s < 0) {
      setStatus('error');
      setPesan('Nama, harga (>0), dan stok wajib benar.');
      setLoading(false);
      return;
    }
    if (intMenit > 0 && durMenit === 0) {
      setStatus('error');
      setPesan('Isi lama aktif dulu kalau ingin ada klaim berkala.');
      setLoading(false);
      return;
    }
    if (intMenit > 0 && intMenit > durMenit) {
      setStatus('error');
      setPesan('Interval klaim tidak boleh lebih besar dari lama aktif.');
      setLoading(false);
      return;
    }
    if (intMenit > 0 && saldoKlaim <= 0) {
      setStatus('error');
      setPesan('Isi nominal saldo untuk tiap klaim.');
      setLoading(false);
      return;
    }

    try {
      let gambarPath: string | null = null;
      let uploadWarn = '';

      // 1) Upload gambar (opsional) — gagal upload TIDAK batalkan simpan produk
      if (file) {
        setPesan('Mengunggah gambar…');
        try {
          const fd = new FormData();
          fd.set('file', file);
          const upRes = await fetch('/api/upload', { method: 'POST', body: fd, credentials: 'same-origin' });
          const up = await parseJson(upRes);
          if (up.data?.status === 'sukses') {
            gambarPath = up.data.url || up.data.path || null;
          } else {
            uploadWarn = up.data?.pesan || `Upload HTTP ${up.status}`;
          }
        } catch (ue) {
          uploadWarn = ue instanceof Error ? ue.message : 'Upload gagal (jaringan)';
        }
      }

      // 2) Simpan produk (JSON — ringan, jarang "fetch failed")
      setPesan('Menyimpan produk ke database…');
      const res = await fetch('/api/produk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
          action: 'produk_simpan',
          id: editId || undefined,
          nama_produk: nama.trim(),
          jenis_produk: jenis.trim() || 'Umum',
          deskripsi: deskripsi.trim(),
          harga: h,
          stok: s,
          durasi_aktif_menit: durMenit,
          interval_aktif_menit: intMenit,
          saldo_per_klaim: saldoKlaim,
          max_klaim: maxKlaim,
          status: produkStatus,
          gambar_path: gambarPath || (gambarUrl.trim() || null),
          level_produk: levelProduk,
          level_syarat: levelSyarat,
          max_beli_per_user: maxBeliPerUser,
        }),
      });
      const out = await parseJson(res);
      if (out.data?.status !== 'sukses') {
        throw new Error(out.data?.pesan || out.raw || `Gagal simpan (HTTP ${out.status})`);
      }

      let okMsg = out.data.pesan || 'Produk tersimpan';
      if (uploadWarn) {
        // produk OK tapi gambar gagal → anggap error visual (merah) supaya admin sadar
        setStatus('error');
        okMsg =
          'Produk tersimpan di database, TAPI gambar gagal diunggah. ' +
          'Publikasikan di Kelola Produk, lalu edit & unggah gambar ulang. Penyebab: ' +
          uploadWarn;
      } else {
        setStatus('sukses');
      }
      setPesan(okMsg);

      setNama('');
      setJenis('');
      setDeskripsi('');
      setHarga('');
      setStok('0');
      setFile(null);
      setDurasi(0);
      setIntervalVal(0);
      setSaldoKlaim(0);
      setMaxKlaim(0);
    } catch (err) {
      setStatus('error');
      const m = err instanceof Error ? err.message : 'Gagal menyimpan';
      // Jangan hanya "fetch failed" — tambah petunjuk
      if (/fetch failed|Failed to fetch|NetworkError/i.test(m)) {
        setPesan(
          `${m}. Coba: 1) Simpan TANPA gambar dulu. 2) Buka /api/health cek env. 3) Pastikan SUPABASE_SECRET = service_role key (JWT) di Vercel.`
        );
      } else {
        setPesan(m);
      }
    }
    setLoading(false);
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, gap: 12, flexWrap: 'wrap' }}>
        <div>
          <h1 className="page-title" style={{ marginBottom: 4 }}>
            Buat Produk & Jadwal
          </h1>
          <p style={{ color: 'var(--muted)', fontSize: 13 }}>Atur gambar dan aturan masa aktif produk setelah dibeli client</p>
        </div>
        <Link href="/produk" className="btn btn-ghost">
          ← Kembali ke Kelola Produk
        </Link>
      </div>

      {status !== 'idle' && <div className={`alert ${status === 'sukses' ? 'sukses' : 'error'}`}>{pesan}</div>}
      {status === 'idle' && pesan && <p style={{ color: 'var(--muted)', marginBottom: 10 }}>{pesan}</p>}

      <form className="card" onSubmit={onSubmit} style={{ maxWidth: 640 }}>
        <h3 style={{ marginBottom: 12 }}>Informasi Produk</h3>
        <label className="label">Nama Produk *</label>
        <input className="input" value={nama} onChange={(e) => setNama(e.target.value)} required style={{ width: '100%', marginBottom: 10 }} />
        <label className="label">Jenis Produk</label>
        <input className="input" value={jenis} onChange={(e) => setJenis(e.target.value)} placeholder="mis. POP" style={{ width: '100%', marginBottom: 10 }} />
        <label className="label">Gambar Produk (opsional — JPG/PNG/WEBP, max 5MB)</label>
        <input
          className="input"
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          onChange={(e) => setFile(e.target.files?.[0] || null)}
          style={{ width: '100%', marginBottom: 10 }}
        />
        {file && (
          <p style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 8 }}>
            {file.name} ({Math.round(file.size / 1024)} KB)
          </p>
        )}
        <label className="label">Atau URL gambar (jika upload gagal)</label>
        <input className="input" value={gambarUrl} onChange={(e) => setGambarUrl(e.target.value)} placeholder="https://...supabase.co/storage/..." style={{ width: '100%', marginBottom: 10 }} />
        <label className="label">Deskripsi</label>
        <textarea className="input" value={deskripsi} onChange={(e) => setDeskripsi(e.target.value)} rows={3} style={{ width: '100%', marginBottom: 10 }} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 10 }}>
          <div>
            <label className="label">Harga (Rp) *</label>
            <input className="input" type="number" min={1} value={harga} onChange={(e) => setHarga(e.target.value)} required style={{ width: '100%' }} />
          </div>
          <div>
            <label className="label">Stok</label>
            <input className="input" type="number" min={0} value={stok} onChange={(e) => setStok(e.target.value)} style={{ width: '100%' }} />
          </div>
        </div>

        <h3 style={{ margin: '16px 0 10px' }}>Aturan Setelah Dibeli Client</h3>
        <label className="label">Lama produk aktif setelah dibeli (0 = tanpa batas)</label>
        <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
          <input className="input" type="number" min={0} value={durasi} onChange={(e) => setDurasi(Number(e.target.value) || 0)} style={{ flex: 1 }} />
          <select className="input" value={durasiUnit} onChange={(e) => setDurasiUnit(Number(e.target.value))} style={{ width: 120 }}>
            {UNITS.map((u) => (
              <option key={u.label} value={u.value}>
                {u.label}
              </option>
            ))}
          </select>
        </div>
        <label className="label">Klaim saldo tersedia tiap (0 = tidak ada klaim berkala)</label>
        <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
          <input className="input" type="number" min={0} value={interval} onChange={(e) => setIntervalVal(Number(e.target.value) || 0)} style={{ flex: 1 }} />
          <select className="input" value={intervalUnit} onChange={(e) => setIntervalUnit(Number(e.target.value))} style={{ width: 120 }}>
            {UNITS.map((u) => (
              <option key={u.label} value={u.value}>
                {u.label}
              </option>
            ))}
          </select>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 10 }}>
          <div>
            <label className="label">Saldo tiap klaim (Rp)</label>
            <input className="input" type="number" min={0} value={saldoKlaim} onChange={(e) => setSaldoKlaim(Number(e.target.value) || 0)} style={{ width: '100%' }} />
          </div>
          <div>
            <label className="label">Maksimal klaim (0 = tanpa batas)</label>
            <input className="input" type="number" min={0} value={maxKlaim} onChange={(e) => setMaxKlaim(Number(e.target.value) || 0)} style={{ width: '100%' }} />
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 10 }}>
          <div>
            <label className="label">Level produk</label>
            <input className="input" type="number" min={1} max={20} value={levelProduk} onChange={(e) => setLevelProduk(Number(e.target.value) || 1)} style={{ width: '100%' }} />
            <p style={{ fontSize: 11, color: 'var(--muted)', marginTop: 4 }}>Lv1 bebas. Lv2 butuh pernah/aktif Lv1, dst.</p>
          </div>
          <div>
            <label className="label">Syarat level bawah</label>
            <select className="input" value={levelSyarat} onChange={(e) => setLevelSyarat(e.target.value as 'pernah' | 'aktif')} style={{ width: '100%' }}>
              <option value="pernah">Pernah beli level bawah</option>
              <option value="aktif">Masih punya level bawah aktif</option>
            </select>
          </div>
        </div>
        <div style={{ marginBottom: 10 }}>
          <label className="label">Maksimal beli per client (0 = tak terbatas)</label>
          <input className="input" type="number" min={0} max={999} value={maxBeliPerUser} onChange={(e) => setMaxBeliPerUser(Number(e.target.value) || 0)} style={{ width: '100%' }} />
          <p style={{ fontSize: 11, color: 'var(--muted)', marginTop: 4 }}>Contoh: 1 = tiap client hanya boleh beli produk ini 1 kali.</p>
        </div>
        <label className="label">Status awal</label>
        <select className="input" value={produkStatus} onChange={(e) => setProdukStatus(e.target.value)} style={{ width: '100%', marginBottom: 10 }}>
          <option value="nonaktif">Draft (nonaktif)</option>
          <option value="aktif">Aktif langsung</option>
        </select>

        <div
          style={{
            background: 'rgba(250,204,21,0.08)',
            border: '1px dashed rgba(250,204,21,0.35)',
            borderRadius: 10,
            padding: 12,
            fontSize: 13,
            marginBottom: 14,
          }}
        >
          {ringkas}
        </div>

        <button className="btn btn-primary" type="submit" disabled={loading}>
          {loading ? 'Menyimpan…' : 'Simpan Produk'}
        </button>
        <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 10 }}>
          Tips: jika error, coba simpan <b>tanpa gambar</b> dulu. Lalu buka{' '}
          <a href="/api/health" target="_blank" rel="noreferrer" style={{ color: 'var(--primary)' }}>
            /api/health
          </a>{' '}
          untuk cek koneksi DB & Supabase.
        </p>
      </form>
    </div>
  );
}


export default function ProdukBuatPage() {
  return (
    <Suspense fallback={<div style={{ padding: 24 }}>Memuat…</div>}>
      <ProdukBuatInner />
    </Suspense>
  );
}
